// Generates the app icons from SVG. Run: NODE_PATH=$(npm root -g) node scripts/make-icons.cjs
const sharp = require('sharp');
const path = require('path');

const GREEN = '#0D5C3F';
const GOLD = '#D4A24E';

const star = (size, stroke = 3) => `
  <g transform="translate(${(1024 - size) / 2} ${(1024 - size) / 2}) scale(${size / 100})">
    <polygon points="20,20 80,20 80,80 20,80" fill="none" stroke="${GOLD}" stroke-width="${stroke}"/>
    <polygon points="50,7.6 92.4,50 50,92.4 7.6,50" fill="none" stroke="${GOLD}" stroke-width="${stroke}"/>
    <polygon points="50,24 76,50 50,76 24,50" fill="none" stroke="${GOLD}" stroke-width="${stroke * 0.7}"/>
    <circle cx="50" cy="50" r="6" fill="none" stroke="${GOLD}" stroke-width="${stroke * 0.7}"/>
  </g>`;

const svgs = {
  'icon.png': `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024"><rect width="1024" height="1024" fill="${GREEN}"/>${star(760)}</svg>`,
  'adaptive-icon.png': `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024">${star(560)}</svg>`,
  'splash-icon.png': `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024">${star(520)}</svg>`,
  'favicon.png': `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024"><rect width="1024" height="1024" fill="${GREEN}"/>${star(760)}</svg>`,
};

(async () => {
  for (const [name, svg] of Object.entries(svgs)) {
    await sharp(Buffer.from(svg)).png().toFile(path.join(__dirname, '..', 'assets', name));
    console.log('wrote', name);
  }
})();
