// Builds src/data/quran.json with the full Quran (114 surahs, 6236 ayahs):
// Uthmani Arabic + English (Sahih International) + Hausa (Abubakar Gumi),
// from the free AlQuran Cloud API (no key). Run:  npm run build:data
//
// It validates the result against the known ayah counts and refuses to
// write anything if the data does not look right.
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { ApiEdition, buildQuran, validateQuran } from '../src/lib/quranBuild';

const BASE = 'https://api.alquran.cloud/v1/quran/';

function arg(name: string, fallback: string): string {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

async function fetchEdition(edition: string): Promise<ApiEdition> {
  const url = BASE + edition;
  console.log('Downloading', url);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} answered HTTP ${res.status}`);
  const body: any = await res.json();
  if (body.code !== 200 || !body.data?.surahs) {
    throw new Error(`${url} returned an unexpected payload: ${JSON.stringify(body).slice(0, 200)}`);
  }
  return body.data as ApiEdition;
}

async function main() {
  const [ar, en, ha] = await Promise.all([
    fetchEdition(arg('ar', 'quran-uthmani')),
    fetchEdition(arg('en', 'en.sahih')),
    fetchEdition(arg('ha', 'ha.gumi')),
  ]);

  const quran = buildQuran(ar, en, ha);
  const problems = validateQuran(quran, { full: true });
  if (problems.length) {
    console.error(`Validation failed (${problems.length} problems). First 20:`);
    problems.slice(0, 20).forEach((p) => console.error(' -', p));
    process.exit(1);
  }

  const out = resolve(__dirname, '../src/data/quran.json');
  writeFileSync(out, JSON.stringify(quran));
  const total = quran.surahs.reduce((n, s) => n + s.ayahs.length, 0);
  console.log(`OK: wrote ${quran.surahs.length} surahs, ${total} ayahs to ${out}`);
}

main().catch((e) => {
  console.error('build:data failed:', e.message ?? e);
  process.exit(1);
});
