import type { NativeStackScreenProps } from '@react-navigation/native-stack';

export type RootStackParams = {
  Tabs: undefined;
  ReadList: undefined;
  Reader: { surah: number; ayah?: number };
  LearnPath: undefined;
  Lesson: { id: string };
  ReciteSelect: undefined;
  ReciteSession: { surah: number };
  MurajaahHome: undefined;
  MurajaahSession: { surah: number };
  Offline: undefined;
};

export type ScreenProps<T extends keyof RootStackParams> = NativeStackScreenProps<RootStackParams, T>;
