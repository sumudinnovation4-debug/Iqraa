import { useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { useProgress } from './store/progress';

/** Counts time spent on a screen toward today's goal (in 5 s ticks while focused). */
export function useSessionTimer() {
  const addSeconds = useProgress((s) => s.addSeconds);
  useFocusEffect(
    useCallback(() => {
      const id = setInterval(() => addSeconds(5), 5000);
      return () => clearInterval(id);
    }, [addSeconds]),
  );
}
