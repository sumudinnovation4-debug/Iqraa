// Pure transform from the AlQuran Cloud API shape to the app's quran.json shape.
// Used by scripts/build-quran-data.ts; kept free of I/O so it can be unit tested.
import { normalizeArabic } from './arabic';
import { AYAH_COUNTS, SURAH_NAMES } from '../data/surahNames';

export interface ApiAyah {
  numberInSurah: number;
  text: string;
  juz: number;
}
export interface ApiSurah {
  number: number;
  name: string;
  revelationType: string;
  ayahs: ApiAyah[];
}
export interface ApiEdition {
  surahs: ApiSurah[];
}

export interface BuiltAyah {
  n: number;
  ar: string;
  en: string;
  ha: string;
  juz: number;
}
export interface BuiltSurah {
  id: number;
  ar: string;
  en: string;
  meaning: string;
  juz: number;
  place: 'Makkah' | 'Madinah';
  ayahs: BuiltAyah[];
}
export interface BuiltQuran {
  surahs: BuiltSurah[];
}

const INVISIBLE = /[​-‏‪-‮﻿]/g;
const BISMILLAH_SKELETON = 'بسم الله الرحمن الرحيم';

const clean = (s: string) => s.replace(INVISIBLE, '').replace(/\s+/g, ' ').trim();

/** Editions prepend the Bismillah to ayah 1 of every surah except Al-Fatiha and At-Tawbah. */
export function stripBismillah(text: string): string {
  const t = clean(text);
  const tokens = t.split(' ');
  if (tokens.length > 4 && normalizeArabic(tokens.slice(0, 4).join(' ')) === BISMILLAH_SKELETON) {
    return tokens.slice(4).join(' ');
  }
  return t;
}

/** "سُورَةُ ٱلْفَاتِحَةِ" -> "ٱلْفَاتِحَةِ" */
export function stripSurahPrefix(name: string): string {
  const t = clean(name);
  const [first, ...rest] = t.split(' ');
  return normalizeArabic(first) === 'سوره' && rest.length ? rest.join(' ') : t;
}

export function buildQuran(ar: ApiEdition, en: ApiEdition, ha: ApiEdition): BuiltQuran {
  if (ar.surahs.length !== en.surahs.length || ar.surahs.length !== ha.surahs.length) {
    throw new Error(
      `Surah count differs between editions (ar ${ar.surahs.length}, en ${en.surahs.length}, ha ${ha.surahs.length})`,
    );
  }
  const surahs: BuiltSurah[] = ar.surahs.map((s, i) => {
    const e = en.surahs[i];
    const h = ha.surahs[i];
    if (e.number !== s.number || h.number !== s.number) {
      throw new Error(`Surah order differs at index ${i} (ar ${s.number}, en ${e.number}, ha ${h.number})`);
    }
    if (e.ayahs.length !== s.ayahs.length || h.ayahs.length !== s.ayahs.length) {
      throw new Error(
        `Ayah count differs in surah ${s.number} (ar ${s.ayahs.length}, en ${e.ayahs.length}, ha ${h.ayahs.length})`,
      );
    }
    const names = SURAH_NAMES[s.number - 1] ?? [`Surah ${s.number}`, ''];
    const ayahs: BuiltAyah[] = s.ayahs.map((a, k) => {
      const arText = k === 0 && s.number !== 1 && s.number !== 9 ? stripBismillah(a.text) : clean(a.text);
      return { n: a.numberInSurah, ar: arText, en: clean(e.ayahs[k].text), ha: clean(h.ayahs[k].text), juz: a.juz };
    });
    return {
      id: s.number,
      ar: stripSurahPrefix(s.name),
      en: names[0],
      meaning: names[1],
      juz: ayahs[0]?.juz ?? 1,
      place: s.revelationType.toLowerCase().startsWith('mecc') ? 'Makkah' : 'Madinah',
      ayahs,
    };
  });
  return { surahs };
}

export interface ValidateOptions {
  /** Require exactly the real Quran: 114 surahs, the known ayah counts, 6236 ayahs. */
  full?: boolean;
}

/** Returns a list of problems; empty means the data looks right. */
export function validateQuran(q: BuiltQuran, { full = true }: ValidateOptions = {}): string[] {
  const errors: string[] = [];
  let total = 0;
  let lastJuz = 0;
  if (full && q.surahs.length !== 114) errors.push(`Expected 114 surahs, got ${q.surahs.length}`);
  q.surahs.forEach((s, i) => {
    if (full && s.id !== i + 1) errors.push(`Surah at index ${i} has id ${s.id}`);
    if (full && s.ayahs.length !== AYAH_COUNTS[s.id - 1]) {
      errors.push(`Surah ${s.id}: expected ${AYAH_COUNTS[s.id - 1]} ayahs, got ${s.ayahs.length}`);
    }
    s.ayahs.forEach((a, k) => {
      total++;
      const where = `${s.id}:${k + 1}`;
      if (a.n !== k + 1) errors.push(`${where}: ayah number ${a.n} out of sequence`);
      if (!a.ar.trim()) errors.push(`${where}: empty Arabic`);
      if (!a.en.trim()) errors.push(`${where}: empty English`);
      if (!a.ha.trim()) errors.push(`${where}: empty Hausa`);
      if (!(a.juz >= 1 && a.juz <= 30)) errors.push(`${where}: juz ${a.juz} out of range`);
      if (a.juz < lastJuz) errors.push(`${where}: juz goes backwards (${a.juz} after ${lastJuz})`);
      lastJuz = a.juz;
      if (k === 0 && s.id !== 1 && s.id !== 9 && normalizeArabic(a.ar).startsWith(BISMILLAH_SKELETON)) {
        errors.push(`${where}: Bismillah still attached to the first ayah`);
      }
    });
  });
  if (full && total !== 6236) errors.push(`Expected 6236 ayahs, got ${total}`);
  return errors;
}
