// Small SM-2 style spaced repetition for memorised surahs.

export type Rating = 0 | 1 | 2 | 3; // again, hard, good, easy

export interface SrsState {
  ease: number;
  intervalDays: number;
  reps: number;
}

export interface Schedule extends SrsState {
  dueAt: number; // epoch ms
}

const DAY = 24 * 60 * 60 * 1000;
const MIN = 60 * 1000;

export const RATING_LABELS: Record<Rating, string> = {
  0: 'Again',
  1: 'Hard',
  2: 'Good',
  3: 'Easy',
};

export function initialState(): SrsState {
  return { ease: 2.5, intervalDays: 0, reps: 0 };
}

export function nextSchedule(
  state: SrsState,
  rating: Rating,
  now: number = Date.now(),
): Schedule {
  let { ease, intervalDays, reps } = state;

  if (rating === 0) {
    return {
      ease: Math.max(1.3, ease - 0.2),
      intervalDays: 0,
      reps: 0,
      dueAt: now + 10 * MIN,
    };
  }

  if (rating === 1) {
    ease = Math.max(1.3, ease - 0.15);
    intervalDays = Math.max(1, Math.round(intervalDays * 1.2));
  } else if (rating === 2) {
    intervalDays =
      intervalDays === 0 ? 1 : intervalDays === 1 ? 3 : Math.round(intervalDays * ease);
  } else {
    ease = ease + 0.15;
    intervalDays =
      intervalDays === 0 ? 3 : Math.round(intervalDays * ease * 1.3) + 1;
  }

  return { ease, intervalDays, reps: reps + 1, dueAt: now + intervalDays * DAY };
}

export function isDue(dueAt: number, now: number = Date.now()): boolean {
  return dueAt <= now;
}

export function describeDue(dueAt: number, now: number = Date.now()): string {
  const diff = dueAt - now;
  if (diff <= 0) return 'Due now';
  const mins = Math.round(diff / MIN);
  if (mins < 60) return `Due in ${mins} min`;
  const hours = Math.round(diff / (60 * MIN));
  if (hours < 24) return `Due in ${hours} h`;
  return `Due in ${Math.round(diff / DAY)} d`;
}
