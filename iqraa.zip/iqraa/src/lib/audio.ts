// Ayah audio from EveryAyah (free, no key). Files are downloaded once and cached in the
// app's document directory, so they play offline afterwards.
import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as FS from 'expo-file-system/legacy';

export const RECITER_FOLDER = 'Alafasy_128kbps'; // Mishary Rashid Alafasy
const pad = (n: number) => String(n).padStart(3, '0');

export const OFFLINE_MSG =
  "This ayah's audio isn't saved on your phone yet. Connect to the internet once to play it, or save it in Profile > Offline downloads.";

/** Rough size of one cached ayah clip, for showing download estimates. */
export const MB_PER_AYAH = 0.075;

export const keyOf = (surah: number, ayah: number) => `${pad(surah)}${pad(ayah)}`;

export const ayahUrl = (surah: number, ayah: number) =>
  `https://everyayah.com/data/${RECITER_FOLDER}/${keyOf(surah, ayah)}.mp3`;

const dir = () => `${FS.documentDirectory}audio/${RECITER_FOLDER}/`;
const pathFor = (surah: number, ayah: number) => `${dir()}${keyOf(surah, ayah)}.mp3`;

async function ensureDir() {
  const info = await FS.getInfoAsync(dir());
  if (!info.exists) await FS.makeDirectoryAsync(dir(), { intermediates: true });
}

/** All cached clips as "SSSAAA" keys, from one directory listing (fast even for thousands of files). */
export async function listCachedKeys(): Promise<Set<string>> {
  try {
    const info = await FS.getInfoAsync(dir());
    if (!info.exists) return new Set();
    const names = await FS.readDirectoryAsync(dir());
    return new Set(names.filter((n) => n.endsWith('.mp3')).map((n) => n.slice(0, 6)));
  } catch {
    return new Set();
  }
}

export async function isAyahCached(surah: number, ayah: number): Promise<boolean> {
  const info = await FS.getInfoAsync(pathFor(surah, ayah));
  return info.exists && (!('size' in info) || info.size > 1000);
}

/** Returns a local file URI, downloading the clip if it is not cached yet. */
export async function ensureAyahAudio(surah: number, ayah: number): Promise<string> {
  const target = pathFor(surah, ayah);
  if (await isAyahCached(surah, ayah)) return target;

  await ensureDir();
  const tmp = `${target}.part`;
  try {
    const res = await FS.downloadAsync(ayahUrl(surah, ayah), tmp);
    if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
    const info = await FS.getInfoAsync(tmp);
    if (!info.exists || ('size' in info && info.size < 1000)) throw new Error('empty download');
    await FS.moveAsync({ from: tmp, to: target });
  } catch {
    await FS.deleteAsync(tmp, { idempotent: true }).catch(() => {});
    throw new Error(OFFLINE_MSG);
  }
  return target;
}

/** Quietly cache a clip in the background; never throws (fails silently when offline). */
export function prefetchAyahAudio(surah: number, ayah: number): void {
  ensureAyahAudio(surah, ayah).catch(() => {});
}

export interface DownloadJob {
  cancelled: boolean;
}

export interface DownloadResult {
  saved: number;
  failed: number;
  /** Stopped early because the connection looks gone. */
  aborted: boolean;
  cancelled: boolean;
}

/**
 * Download many clips, three at a time. Already-saved clips are skipped, so running it
 * again after an interruption simply continues. Stops early after 4 failures in a row.
 */
export async function downloadAyahs(
  items: { s: number; a: number }[],
  job: DownloadJob,
  onProgress: (done: number, total: number) => void,
  concurrency = 3,
): Promise<DownloadResult> {
  const total = items.length;
  let next = 0;
  let done = 0;
  let saved = 0;
  let failed = 0;
  let streak = 0;
  let aborted = false;

  const worker = async () => {
    while (!job.cancelled && !aborted) {
      const i = next++;
      if (i >= total) return;
      try {
        await ensureAyahAudio(items[i].s, items[i].a);
        saved++;
        streak = 0;
      } catch {
        failed++;
        if (++streak >= 4) aborted = true;
      }
      done++;
      onProgress(done, total);
    }
  };

  await Promise.all(Array.from({ length: Math.min(concurrency, Math.max(1, total)) }, worker));
  return { saved, failed, aborted, cancelled: job.cancelled };
}

export async function downloadSurahAudio(
  surah: number,
  ayahCount: number,
  onProgress?: (done: number, total: number) => void,
): Promise<DownloadResult> {
  const items = Array.from({ length: ayahCount }, (_, k) => ({ s: surah, a: k + 1 }));
  const cached = await listCachedKeys();
  const todo = items.filter((i) => !cached.has(keyOf(i.s, i.a)));
  const res = await downloadAyahs(todo, { cancelled: false }, (d, t) => onProgress?.(ayahCount - t + d, ayahCount));
  if (res.aborted || res.failed > 0) throw new Error(OFFLINE_MSG);
  return res;
}

export async function cachedCount(surah: number, ayahCount: number): Promise<number> {
  const set = await listCachedKeys();
  let c = 0;
  for (let n = 1; n <= ayahCount; n++) if (set.has(keyOf(surah, n))) c++;
  return c;
}

// ---- playback ----

let player: AudioPlayer | null = null;
let cancelCurrent: (() => void) | null = null;
let modeSet = false;

function getPlayer(): AudioPlayer {
  if (!player) player = createAudioPlayer();
  return player;
}

export function stopAudio() {
  try {
    player?.pause();
  } catch {}
  cancelCurrent?.();
  cancelCurrent = null;
}

/** Plays one ayah and resolves when it finishes (or is stopped). */
export async function playAyah(surah: number, ayah: number): Promise<void> {
  stopAudio();
  if (!modeSet) {
    modeSet = true;
    try {
      await setAudioModeAsync({ playsInSilentMode: true });
    } catch {}
  }
  const uri = await ensureAyahAudio(surah, ayah);
  const p = getPlayer();
  await new Promise<void>((resolve) => {
    const sub = p.addListener('playbackStatusUpdate', (status) => {
      if (status.didJustFinish) {
        sub.remove();
        cancelCurrent = null;
        resolve();
      }
    });
    cancelCurrent = () => {
      sub.remove();
      resolve();
    };
    p.replace({ uri });
    p.play();
  });
}
