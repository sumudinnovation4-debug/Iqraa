// Ayah audio from EveryAyah (free, no key). Files are downloaded on first use
// and cached in the app's document directory, so they play offline afterwards.
import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as FS from 'expo-file-system/legacy';

export const RECITER_FOLDER = 'Alafasy_128kbps'; // Mishary Rashid Alafasy
const pad = (n: number) => String(n).padStart(3, '0');

export const ayahUrl = (surah: number, ayah: number) =>
  `https://everyayah.com/data/${RECITER_FOLDER}/${pad(surah)}${pad(ayah)}.mp3`;

const dir = () => `${FS.documentDirectory}audio/${RECITER_FOLDER}/`;
const pathFor = (surah: number, ayah: number) => `${dir()}${pad(surah)}${pad(ayah)}.mp3`;

async function ensureDir() {
  const info = await FS.getInfoAsync(dir());
  if (!info.exists) await FS.makeDirectoryAsync(dir(), { intermediates: true });
}

export async function isAyahCached(surah: number, ayah: number): Promise<boolean> {
  const info = await FS.getInfoAsync(pathFor(surah, ayah));
  return info.exists;
}

/** Returns a local file URI, downloading the clip if it is not cached yet. */
export async function ensureAyahAudio(surah: number, ayah: number): Promise<string> {
  const target = pathFor(surah, ayah);
  const info = await FS.getInfoAsync(target);
  if (info.exists) return target;

  await ensureDir();
  const tmp = `${target}.part`;
  const res = await FS.downloadAsync(ayahUrl(surah, ayah), tmp);
  if (res.status !== 200) {
    await FS.deleteAsync(tmp, { idempotent: true });
    throw new Error(`Audio download failed (${res.status}). Connect once to cache it.`);
  }
  await FS.moveAsync({ from: tmp, to: target });
  return target;
}

export async function downloadSurahAudio(
  surah: number,
  ayahCount: number,
  onProgress?: (done: number, total: number) => void,
): Promise<void> {
  for (let n = 1; n <= ayahCount; n++) {
    await ensureAyahAudio(surah, n);
    onProgress?.(n, ayahCount);
  }
}

export async function cachedCount(surah: number, ayahCount: number): Promise<number> {
  let c = 0;
  for (let n = 1; n <= ayahCount; n++) if (await isAyahCached(surah, n)) c++;
  return c;
}

// ---- playback ----

let player: AudioPlayer | null = null;
let cancelCurrent: (() => void) | null = null;
let modeSet = false;

function getPlayer(): AudioPlayer {
  if (!player) player = createAudioPlayer();
  return player;
}

export function stopAudio() {
  try {
    player?.pause();
  } catch {}
  cancelCurrent?.();
  cancelCurrent = null;
}

/** Plays one ayah and resolves when it finishes (or is stopped). */
export async function playAyah(surah: number, ayah: number): Promise<void> {
  stopAudio();
  if (!modeSet) {
    modeSet = true;
    try {
      await setAudioModeAsync({ playsInSilentMode: true });
    } catch {}
  }
  const uri = await ensureAyahAudio(surah, ayah);
  const p = getPlayer();
  await new Promise<void>((resolve) => {
    const sub = p.addListener('playbackStatusUpdate', (status) => {
      if (status.didJustFinish) {
        sub.remove();
        cancelCurrent = null;
        resolve();
      }
    });
    cancelCurrent = () => {
      sub.remove();
      resolve();
    };
    p.replace({ uri });
    p.play();
  });
}
