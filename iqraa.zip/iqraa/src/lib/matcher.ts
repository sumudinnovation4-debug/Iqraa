import { normalizeArabic, similarity } from './arabic';

export type WordStatus = 'pending' | 'correct' | 'wrong';

export interface AlignResult {
  /** One status per expected word. */
  statuses: WordStatus[];
  /** Index of the first wrong word, or -1. */
  firstWrong: number;
  /** What was heard instead (normalised), when a wrong word was heard. */
  heard?: string;
  /** True when every expected word has been matched. */
  complete: boolean;
  /** Number of expected words matched so far. */
  matched: number;
}

/**
 * Fuzzy word comparison tolerant of small ASR spelling differences.
 * Both arguments must already be normalised.
 */
export function wordsMatch(a: string, b: string): boolean {
  if (a === b) return true;
  // Recognisers disagree with Uthmani spelling mostly on long-vowel alefs
  // (مالك vs ملك, العالمين vs العلمين), so ignore alefs when comparing.
  const sa = a.replace(/ا/g, '');
  const sb = b.replace(/ا/g, '');
  if (sa === sb) return true;
  const shortest = Math.min(sa.length, sb.length);
  const longest = Math.max(sa.length, sb.length);
  // Short words must match exactly: one letter changes the word
  // (e.g. واحد vs أحد), so no fuzziness below 5 letters.
  if (shortest <= 2 || longest <= 4) return false;
  return similarity(sa, sb) >= 0.75;
}

/**
 * Align what the recogniser heard against the expected ayah, word by word.
 *
 * @param expected normalised expected words (see expectedWords)
 * @param spokenText raw transcription text (any script marks are stripped)
 * @param final false while the user is still speaking: the last heard word is
 *   not judged yet because it may be a partial. true once they stop: any
 *   expected word never heard is reported as wrong (missed).
 */
export function alignRecitation(
  expected: string[],
  spokenText: string,
  final: boolean,
): AlignResult {
  const spoken = normalizeArabic(spokenText).split(' ').filter(Boolean);
  const statuses: WordStatus[] = expected.map(() => 'pending');
  let i = 0;
  let j = 0;

  const result = (firstWrong: number, heard?: string): AlignResult => ({
    statuses,
    firstWrong,
    heard,
    complete: firstWrong === -1 && i >= expected.length,
    matched: statuses.filter((s) => s === 'correct').length,
  });

  while (i < expected.length && j < spoken.length) {
    const e = expected[i];
    const s = spoken[j];

    if (wordsMatch(e, s)) {
      statuses[i] = 'correct';
      i++;
      j++;
      continue;
    }
    // Recogniser split one expected word into two tokens.
    if (j + 1 < spoken.length && wordsMatch(e, s + spoken[j + 1])) {
      statuses[i] = 'correct';
      i++;
      j += 2;
      continue;
    }
    // Recogniser glued two expected words into one token.
    if (i + 1 < expected.length && wordsMatch(e + expected[i + 1], s)) {
      statuses[i] = 'correct';
      statuses[i + 1] = 'correct';
      i += 2;
      j++;
      continue;
    }
    // A stray extra token (noise / filler) right before the expected word.
    if (j + 1 < spoken.length && wordsMatch(e, spoken[j + 1])) {
      j++;
      continue;
    }
    // The last heard token may still be growing: do not judge it yet.
    if (j === spoken.length - 1 && !final) break;

    statuses[i] = 'wrong';
    return result(i, s);
  }

  if (final && i < expected.length) {
    // Stopped before finishing: the next word was missed.
    statuses[i] = 'wrong';
    return result(i);
  }
  return result(-1);
}
