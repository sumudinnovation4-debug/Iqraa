import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ApiEdition, buildQuran, stripBismillah, stripSurahPrefix, validateQuran } from '../quranBuild';
import { AYAH_COUNTS, SURAH_NAMES } from '../../data/surahNames';
import { QURAN, getAyah, getSurah } from '../../data/quranData';

// Mock of the AlQuran Cloud payload built from the bundled data, with the quirks the real one has:
// Bismillah glued to ayah 1 (with tatweel spelling), "سُورَةُ" prefix, invisible characters.
const BISM_API = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ';
function mock(field: 'ar' | 'en' | 'ha'): ApiEdition {
  return {
    surahs: QURAN.map((s) => ({
      number: s.id,
      name: field === 'ar' ? `سُورَةُ ${s.ar}` : s.en,
      revelationType: 'Meccan',
      ayahs: s.ayahs.map((a, k) => ({
        numberInSurah: a.n,
        juz: a.juz,
        text:
          field === 'ar' && k === 0 && s.id !== 1
            ? `﻿${BISM_API} ${a[field]}`
            : a[field],
      })),
    })),
  };
}

test('tables: 114 names, 114 counts, 6236 ayahs', () => {
  assert.equal(SURAH_NAMES.length, 114);
  assert.equal(AYAH_COUNTS.length, 114);
  assert.equal(AYAH_COUNTS.reduce((a, b) => a + b, 0), 6236);
});

test('stripBismillah removes the glued Bismillah but never touches Al-Fatiha ayah 1', () => {
  assert.equal(stripBismillah(`${BISM_API} قُلْ هُوَ ٱللَّهُ أَحَدٌ`), 'قُلْ هُوَ ٱللَّهُ أَحَدٌ');
  assert.equal(stripBismillah(BISM_API), BISM_API); // nothing after it: keep (Al-Fatiha 1:1)
});

test('stripSurahPrefix', () => {
  assert.equal(stripSurahPrefix('سُورَةُ ٱلْفَاتِحَةِ'), 'ٱلْفَاتِحَةِ');
  assert.equal(stripSurahPrefix('ٱلْفَاتِحَة'), 'ٱلْفَاتِحَة');
});

test('buildQuran reproduces the bundled text from the API-shaped payload', () => {
  const built = buildQuran(mock('ar'), mock('en'), mock('ha'));
  assert.equal(built.surahs.length, QURAN.length);
  for (const s of built.surahs) {
    const orig = getSurah(s.id);
    assert.equal(s.ayahs.length, orig.ayahs.length);
    assert.equal(s.ayahs[0].ar, orig.ayahs[0].ar, `bismillah stripped in ${s.id}`);
    assert.equal(s.ayahs[0].ha, orig.ayahs[0].ha);
    assert.equal(s.en, SURAH_NAMES[s.id - 1][0]);
    assert.equal(s.ar, orig.ar);
  }
  assert.deepEqual(validateQuran(built, { full: false }), []);
});

test('validateQuran in full mode rejects partial data and reports why', () => {
  const built = buildQuran(mock('ar'), mock('en'), mock('ha'));
  const problems = validateQuran(built, { full: true });
  assert.ok(problems.some((p) => p.includes('Expected 114 surahs')));
});

test('buildQuran rejects mismatched editions', () => {
  const ar = mock('ar');
  const en = mock('en');
  en.surahs[0].ayahs.pop();
  assert.throws(() => buildQuran(ar, en, mock('ha')), /Ayah count differs/);
});

test('validateQuran catches empty Hausa, bad juz and leftover Bismillah', () => {
  const built = buildQuran(mock('ar'), mock('en'), mock('ha'));
  built.surahs[0].ayahs[1].ha = '';
  built.surahs[1].ayahs[0].juz = 99;
  built.surahs[1].ayahs[0].ar = `${BISM_API} ${built.surahs[1].ayahs[0].ar}`;
  const problems = validateQuran(built, { full: false });
  assert.ok(problems.some((p) => p.includes('empty Hausa')));
  assert.ok(problems.some((p) => p.includes('out of range')));
  assert.ok(problems.some((p) => p.includes('Bismillah still attached')));
});

test('data loader: every ayah has Arabic, English and Hausa; getAyah works', () => {
  for (const s of QURAN) for (const a of s.ayahs) assert.ok(a.ar && a.en && a.ha, `${s.id}:${a.n}`);
  assert.equal(getAyah(1, 2).n, 2);
});
