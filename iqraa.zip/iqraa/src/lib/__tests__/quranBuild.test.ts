import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ApiEdition, buildQuran, stripBismillah, stripSurahPrefix, validateQuran, BuiltQuran } from '../quranBuild';
import { AYAH_COUNTS, SURAH_NAMES } from '../../data/surahNames';
import { QURAN, getSurah } from '../../data/quranData';

// A small fixed fixture, independent of whatever quran.json is bundled (2 surahs or all 114).
// It includes At-Tawbah (9), which has no Bismillah, and the quirks the real API has:
// Bismillah glued to ayah 1 (tatweel spelling), "سُورَةُ" name prefix, invisible characters.
const BISM_API = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ';

interface Fixture {
  id: number;
  ar: string;
  ayahs: { n: number; ar: string; en: string; ha: string; juz: number }[];
}

const TAWBAH_1 = 'بَرَآءَةٌ مِّنَ ٱللَّهِ وَرَسُولِهِۦٓ إِلَى ٱلَّذِينَ عَٰهَدتُّم مِّنَ ٱلْمُشْرِكِينَ';

const FIXTURE: Fixture[] = [
  { id: 1, ar: getSurah(1).ar, ayahs: getSurah(1).ayahs },
  {
    id: 9,
    ar: 'ٱلتَّوْبَة',
    ayahs: [
      { n: 1, ar: TAWBAH_1, en: 'Freedom from obligation.', ha: 'Barranta daga Allah.', juz: 10 },
      { n: 2, ar: 'فَسِيحُوا۟ فِى ٱلْأَرْضِ', en: 'Travel freely.', ha: 'Ku yi yawo.', juz: 10 },
    ],
  },
  { id: 112, ar: getSurah(112).ar, ayahs: getSurah(112).ayahs },
];

function mock(field: 'ar' | 'en' | 'ha'): ApiEdition {
  return {
    surahs: FIXTURE.map((s) => ({
      number: s.id,
      name: field === 'ar' ? `سُورَةُ ${s.ar}` : `name ${s.id}`,
      revelationType: s.id === 9 ? 'Medinan' : 'Meccan',
      ayahs: s.ayahs.map((a, k) => ({
        numberInSurah: a.n,
        juz: a.juz,
        // The real Arabic edition glues the Bismillah to ayah 1 of every surah except 1 and 9.
        text:
          field === 'ar' && k === 0 && s.id !== 1 && s.id !== 9 ? `﻿${BISM_API} ${a.ar}` : a[field],
      })),
    })),
  };
}

function built(): BuiltQuran {
  return buildQuran(mock('ar'), mock('en'), mock('ha'));
}

test('tables: 114 names, 114 counts, 6236 ayahs', () => {
  assert.equal(SURAH_NAMES.length, 114);
  assert.equal(AYAH_COUNTS.length, 114);
  assert.equal(AYAH_COUNTS.reduce((a, b) => a + b, 0), 6236);
});

test('stripBismillah removes the glued Bismillah but keeps a lone one (Al-Fatiha 1:1)', () => {
  assert.equal(stripBismillah(`${BISM_API} قُلْ هُوَ ٱللَّهُ أَحَدٌ`), 'قُلْ هُوَ ٱللَّهُ أَحَدٌ');
  assert.equal(stripBismillah(BISM_API), BISM_API);
});

test('stripSurahPrefix', () => {
  assert.equal(stripSurahPrefix('سُورَةُ ٱلْفَاتِحَةِ'), 'ٱلْفَاتِحَةِ');
  assert.equal(stripSurahPrefix('ٱلْفَاتِحَة'), 'ٱلْفَاتِحَة');
});

test('buildQuran: strips Bismillah where it is glued, leaves 1 and 9 untouched', () => {
  const q = built();
  assert.equal(q.surahs.length, 3);
  for (const s of q.surahs) {
    const orig = FIXTURE.find((f) => f.id === s.id)!;
    assert.equal(s.ayahs.length, orig.ayahs.length);
    assert.equal(s.ayahs[0].ar, orig.ayahs[0].ar, `ayah text of surah ${s.id}`);
    assert.equal(s.ayahs[0].ha, orig.ayahs[0].ha);
    assert.equal(s.en, SURAH_NAMES[s.id - 1][0]);
    assert.equal(s.ar, orig.ar);
  }
  assert.equal(q.surahs[1].place, 'Madinah');
  assert.equal(q.surahs[0].place, 'Makkah');
  assert.deepEqual(validateQuran(q, { full: false }), []);
});

test('validateQuran in full mode rejects partial data and says why', () => {
  const problems = validateQuran(built(), { full: true });
  assert.ok(problems.some((p) => p.includes('Expected 114 surahs')));
});

test('buildQuran rejects mismatched editions', () => {
  const en = mock('en');
  en.surahs[0].ayahs.pop();
  assert.throws(() => buildQuran(mock('ar'), en, mock('ha')), /Ayah count differs/);
});

test('validateQuran catches empty Hausa, bad juz and leftover Bismillah', () => {
  const q = built();
  q.surahs[0].ayahs[1].ha = '';
  q.surahs[2].ayahs[0].juz = 99;
  q.surahs[2].ayahs[0].ar = `${BISM_API} ${q.surahs[2].ayahs[0].ar}`;
  const problems = validateQuran(q, { full: false });
  assert.ok(problems.some((p) => p.includes('empty Hausa')));
  assert.ok(problems.some((p) => p.includes('out of range')));
  assert.ok(problems.some((p) => p.includes('Bismillah still attached')));
});

test('bundled quran.json passes validation (full rules when all 114 surahs are present)', () => {
  const q: BuiltQuran = { surahs: QURAN.map((s) => ({ ...s, place: s.place as 'Makkah' | 'Madinah' })) };
  const full = QURAN.length === 114;
  assert.deepEqual(validateQuran(q, { full }), []);
  if (full) assert.equal(QURAN.reduce((n, s) => n + s.ayahs.length, 0), 6236);
});
