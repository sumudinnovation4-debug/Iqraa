import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeArabic, expectedWords, displayWords } from '../arabic';
import { alignRecitation, wordsMatch } from '../matcher';
import { nextSchedule, initialState } from '../srs';
import { QURAN } from '../../data/quranData';

const fatiha = QURAN[0];
const ayah2 = fatiha.ayahs[1]; // ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ
const exp2 = expectedWords(ayah2.ar);

test('normalize strips harakat and unifies alef forms', () => {
  assert.equal(normalizeArabic('ٱلرَّحْمَٰنِ'), 'الرحمن');
  assert.equal(normalizeArabic('إِيَّاكَ'), 'اياك');
  assert.equal(normalizeArabic('لَّهُۥ'), 'له');
});

test('every bundled ayah splits into the same number of display and expected words', () => {
  for (const s of QURAN) {
    for (const a of s.ayahs) {
      assert.equal(displayWords(a.ar).length, expectedWords(a.ar).length);
      assert.ok(expectedWords(a.ar).every((w) => w.length > 0), `${s.en}:${a.n}`);
    }
  }
});

test('perfect recitation completes with all words correct', () => {
  const r = alignRecitation(exp2, 'الحمد لله رب العالمين', true);
  assert.equal(r.complete, true);
  assert.equal(r.firstWrong, -1);
  assert.deepEqual(r.statuses, ['correct', 'correct', 'correct', 'correct']);
});

test('spelling variants from the recogniser are tolerated', () => {
  assert.ok(wordsMatch('العلمين', 'العالمين'));
  assert.ok(wordsMatch('الصرط', 'الصراط'));
});

test('a wrong word is flagged in the middle of speech', () => {
  const r = alignRecitation(exp2, 'الحمد لله كتاب العالمين', false);
  assert.equal(r.firstWrong, 2);
  assert.deepEqual(r.statuses, ['correct', 'correct', 'wrong', 'pending']);
});

test('the last heard word is not judged while still speaking', () => {
  const r = alignRecitation(exp2, 'الحمد لله رب ال', false);
  assert.equal(r.firstWrong, -1);
  assert.equal(r.complete, false);
});

test('stopping early marks the next word as missed', () => {
  const r = alignRecitation(exp2, 'الحمد لله', true);
  assert.equal(r.firstWrong, 2);
});

test('a glued or split token still matches', () => {
  assert.equal(alignRecitation(exp2, 'الحمدلله رب العالمين', true).complete, true);
  assert.equal(alignRecitation(exp2, 'الحمد لله ر ب العالمين', true).complete, true);
});

test('a single stray filler token before the expected word is ignored', () => {
  const r = alignRecitation(exp2, 'نعم الحمد لله رب العالمين', true);
  assert.equal(r.complete, true);
});

test('wrong first word is caught', () => {
  const r = alignRecitation(expectedWords(QURAN[1].ayahs[0].ar), 'قل هو الله واحد', true);
  assert.equal(r.firstWrong, 3);
});

test('srs: good ratings grow the interval, again resets it', () => {
  let s = initialState();
  const now = 1_000_000;
  const a = nextSchedule(s, 2, now);
  assert.equal(a.intervalDays, 1);
  const b = nextSchedule(a, 2, now);
  assert.equal(b.intervalDays, 3);
  const c = nextSchedule(b, 2, now);
  assert.ok(c.intervalDays >= 7);
  const d = nextSchedule(c, 0, now);
  assert.equal(d.intervalDays, 0);
  assert.equal(d.reps, 0);
  assert.ok(d.dueAt - now === 10 * 60 * 1000);
});
