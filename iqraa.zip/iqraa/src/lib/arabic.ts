// Arabic text helpers shared by the reader, lessons and the recitation checker.

// Quranic marks, harakat, tanween, shadda, sukoon, dagger alef, small high marks.
const MARKS = /[ؐ-ًؚ-ٰٟۖ-ۭ࣓-ࣿ]/g;

/**
 * Reduce a word to its consonantal skeleton so that Uthmani text and
 * Whisper's (undiacritised, Modern Standard) output can be compared.
 */
export function normalizeArabic(input: string): string {
  return input
    .replace(/ـ/g, '') // tatweel
    .replace(MARKS, '')
    .replace(/[ٱآأإ]/g, 'ا') // alef wasla / madda / hamza forms -> alef
    .replace(/ى/g, 'ي') // alef maqsura -> ya
    .replace(/ة/g, 'ه') // ta marbuta -> ha
    .replace(/ؤ/g, 'و') // hamza on waw -> waw
    .replace(/ئ/g, 'ي') // hamza on ya -> ya
    .replace(/[^ء-ي\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Split an Uthmani ayah into display words. Standalone waqf / pause signs
 * (tokens that normalise to nothing) are attached to the previous word.
 */
export function displayWords(text: string): string[] {
  const out: string[] = [];
  for (const token of text.trim().split(/\s+/)) {
    if (!token) continue;
    if (normalizeArabic(token) === '' && out.length > 0) {
      out[out.length - 1] += ' ' + token;
    } else {
      out.push(token);
    }
  }
  return out;
}

/** Normalised form of each display word, same length and order. */
export function expectedWords(text: string): string[] {
  return displayWords(text).map(normalizeArabic);
}

export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
    }
    prev = cur;
  }
  return prev[b.length];
}

export function similarity(a: string, b: string): number {
  const max = Math.max(a.length, b.length);
  if (max === 0) return 1;
  return 1 - levenshtein(a, b) / max;
}
