// On-device speech recognition for Recite Mode.
//
// NOTE: @xenova/transformers cannot run inside React Native (it needs the
// browser WASM/ONNX runtime). whisper.rn runs the same Whisper models natively
// through whisper.cpp: free, offline after the one-time model download.
import * as FS from 'expo-file-system/legacy';
import { initWhisper, WhisperContext } from 'whisper.rn';
import { getKv, setKv } from '../db/db';

export type ModelKey = 'base' | 'small';

export const MODELS: Record<ModelKey, { file: string; label: string; mb: number; note: string; url: string }> = {
  base: {
    file: 'ggml-base.bin',
    label: 'Base',
    mb: 142,
    note: 'Faster, smaller download',
    url: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin',
  },
  small: {
    file: 'ggml-small.bin',
    label: 'Small',
    mb: 466,
    note: 'More accurate, larger download',
    url: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin',
  },
};

const modelDir = () => `${FS.documentDirectory}models/`;
const modelPath = (k: ModelKey) => `${modelDir()}${MODELS[k].file}`;

export async function installedModels(): Promise<ModelKey[]> {
  const out: ModelKey[] = [];
  for (const k of Object.keys(MODELS) as ModelKey[]) {
    const info = await FS.getInfoAsync(modelPath(k));
    // Guard against truncated downloads.
    if (info.exists && 'size' in info && info.size > MODELS[k].mb * 1024 * 1024 * 0.9) out.push(k);
  }
  return out;
}

export async function preferredModel(): Promise<ModelKey | null> {
  const installed = await installedModels();
  if (installed.length === 0) return null;
  const saved = (await getKv('model')) as ModelKey | null;
  if (saved && installed.includes(saved)) return saved;
  return installed.includes('small') ? 'small' : installed[0];
}

export async function downloadModel(key: ModelKey, onProgress: (fraction: number) => void): Promise<void> {
  const info = await FS.getInfoAsync(modelDir());
  if (!info.exists) await FS.makeDirectoryAsync(modelDir(), { intermediates: true });
  const tmp = `${modelPath(key)}.part`;
  await FS.deleteAsync(tmp, { idempotent: true });
  const task = FS.createDownloadResumable(MODELS[key].url, tmp, {}, (p) => {
    if (p.totalBytesExpectedToWrite > 0) onProgress(p.totalBytesWritten / p.totalBytesExpectedToWrite);
  });
  const res = await task.downloadAsync();
  if (!res || res.status !== 200) {
    await FS.deleteAsync(tmp, { idempotent: true });
    throw new Error('Model download failed. Check your connection and try again.');
  }
  await FS.moveAsync({ from: tmp, to: modelPath(key) });
  await setKv('model', key);
}

export async function removeModel(key: ModelKey): Promise<void> {
  await FS.deleteAsync(modelPath(key), { idempotent: true });
  if (ctx && ctxKey === key) {
    await ctx.release().catch(() => {});
    ctx = null;
    ctxKey = null;
  }
}

let ctx: WhisperContext | null = null;
let ctxKey: ModelKey | null = null;

export async function loadModel(key: ModelKey): Promise<void> {
  if (ctx && ctxKey === key) return;
  if (ctx) await ctx.release().catch(() => {});
  ctx = await initWhisper({ filePath: modelPath(key).replace('file://', '') });
  ctxKey = key;
}

export interface Listener {
  stop: () => Promise<void>;
}

/**
 * Start live transcription of the microphone. `onText` receives the full
 * transcript heard so far in this session each time it updates.
 */
export async function startListening(onText: (text: string, capturing: boolean) => void): Promise<Listener> {
  if (!ctx) throw new Error('Speech model is not loaded');
  const { stop, subscribe } = await ctx.transcribeRealtime({
    language: 'ar',
    realtimeAudioSec: 30,
    realtimeAudioSliceSec: 4,
  });
  subscribe((evt: any) => {
    onText(evt?.data?.result ?? '', Boolean(evt?.isCapturing));
  });
  return { stop: async () => void (await stop()) };
}
