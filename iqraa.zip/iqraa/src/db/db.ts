import * as SQLite from 'expo-sqlite';
import { QURAN, AYAH_TOTAL } from '../data/quranData';
import { normalizeArabic } from '../lib/arabic';
import { Schedule, initialState } from '../lib/srs';

// Changes whenever the bundled Quran text changes (count + a cheap content checksum),
// so swapping quran.json automatically re-seeds the tables on next launch.
const CONTENT_SUM = QURAN.reduce(
  (sum, s) => s.ayahs.reduce((n, a) => n + a.ar.length + a.en.length + a.ha.length, sum),
  0,
);
const DATA_VERSION = `v3-${QURAN.length}-${AYAH_TOTAL}-${CONTENT_SUM}`;

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) dbPromise = init();
  return dbPromise;
}

async function init(): Promise<SQLite.SQLiteDatabase> {
  const db = await SQLite.openDatabaseAsync('iqraa.db');
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS surahs (
      id INTEGER PRIMARY KEY, ar TEXT, en TEXT, meaning TEXT, juz INTEGER,
      place TEXT, ayah_count INTEGER
    );
    CREATE TABLE IF NOT EXISTS ayahs (
      surah INTEGER, n INTEGER, ar TEXT, ar_plain TEXT, en TEXT, ha TEXT, juz INTEGER,
      PRIMARY KEY (surah, n)
    );
    CREATE INDEX IF NOT EXISTS idx_ayahs_juz ON ayahs (juz);
    CREATE TABLE IF NOT EXISTS bookmarks (
      surah INTEGER, n INTEGER, created INTEGER, PRIMARY KEY (surah, n)
    );
    CREATE TABLE IF NOT EXISTS murajaah (
      surah INTEGER PRIMARY KEY, ease REAL, interval_days INTEGER, reps INTEGER, due_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS activity (
      day TEXT PRIMARY KEY, seconds INTEGER DEFAULT 0, xp INTEGER DEFAULT 0
    );
  `);
  await seed(db);
  return db;
}

async function seed(db: SQLite.SQLiteDatabase) {
  const row = await db.getFirstAsync<{ value: string }>(
    'SELECT value FROM kv WHERE key = ?',
    ['data_version'],
  );
  if (row?.value === DATA_VERSION) return;

  await db.withTransactionAsync(async () => {
    await db.runAsync('DELETE FROM ayahs');
    await db.runAsync('DELETE FROM surahs');
    for (const s of QURAN) {
      await db.runAsync(
        'INSERT INTO surahs (id, ar, en, meaning, juz, place, ayah_count) VALUES (?,?,?,?,?,?,?)',
        [s.id, s.ar, s.en, s.meaning, s.juz, s.place, s.ayahs.length],
      );
      // Multi-row inserts (80 rows x 7 params stays under SQLite's variable limit).
      const CHUNK = 80;
      for (let i = 0; i < s.ayahs.length; i += CHUNK) {
        const part = s.ayahs.slice(i, i + CHUNK);
        const placeholders = part.map(() => '(?,?,?,?,?,?,?)').join(',');
        const params = part.flatMap((a) => [s.id, a.n, a.ar, normalizeArabic(a.ar), a.en, a.ha, a.juz]);
        await db.runAsync(
          `INSERT INTO ayahs (surah, n, ar, ar_plain, en, ha, juz) VALUES ${placeholders}`,
          params,
        );
      }
    }
    await db.runAsync('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)', [
      'data_version',
      DATA_VERSION,
    ]);
  });
}

// ---------- key/value ----------

export async function getKv(key: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM kv WHERE key = ?', [key]);
  return row?.value ?? null;
}

export async function setKv(key: string, value: string): Promise<void> {
  const db = await getDb();
  await db.runAsync('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)', [key, value]);
}

// ---------- reading ----------

export interface SurahRow {
  id: number;
  ar: string;
  en: string;
  meaning: string;
  juz: number;
  place: string;
  ayah_count: number;
}

export interface AyahRow {
  surah: number;
  n: number;
  ar: string;
  en: string;
  ha: string;
  juz: number;
}

export async function listSurahs(query = '', juz: number | null = null): Promise<SurahRow[]> {
  const db = await getDb();
  const q = query.trim();
  const where: string[] = [];
  const params: (string | number)[] = [];
  if (juz !== null) {
    // A surah can span several juz, so match on its ayahs rather than its first juz.
    where.push('id IN (SELECT DISTINCT surah FROM ayahs WHERE juz = ?)');
    params.push(juz);
  }
  if (q) {
    where.push('(en LIKE ? OR meaning LIKE ? OR CAST(id AS TEXT) = ? OR ar LIKE ?)');
    params.push(`%${q}%`, `%${q}%`, q, `%${q}%`);
  }
  const sql = `SELECT * FROM surahs ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id`;
  return db.getAllAsync<SurahRow>(sql, params);
}

export async function getSurahRow(id: number): Promise<SurahRow | null> {
  const db = await getDb();
  return db.getFirstAsync<SurahRow>('SELECT * FROM surahs WHERE id = ?', [id]);
}

export async function getAyahs(surah: number): Promise<AyahRow[]> {
  const db = await getDb();
  return db.getAllAsync<AyahRow>('SELECT * FROM ayahs WHERE surah = ? ORDER BY n', [surah]);
}

export async function listJuz(): Promise<number[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ juz: number }>('SELECT DISTINCT juz FROM ayahs ORDER BY juz');
  return rows.map((r) => r.juz);
}

/** Search ayahs by Arabic (diacritics ignored), English or Hausa translation. */
export async function searchAyahs(query: string, limit = 30): Promise<AyahRow[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const db = await getDb();
  const plain = normalizeArabic(q);
  return db.getAllAsync<AyahRow>(
    `SELECT * FROM ayahs
     WHERE en LIKE ? OR ha LIKE ? ${plain ? 'OR ar_plain LIKE ?' : ''}
     ORDER BY surah, n LIMIT ?`,
    plain ? [`%${q}%`, `%${q}%`, `%${plain}%`, limit] : [`%${q}%`, `%${q}%`, limit],
  );
}

// ---------- bookmarks ----------

export async function toggleBookmark(surah: number, n: number): Promise<boolean> {
  const db = await getDb();
  const existing = await db.getFirstAsync('SELECT 1 FROM bookmarks WHERE surah = ? AND n = ?', [surah, n]);
  if (existing) {
    await db.runAsync('DELETE FROM bookmarks WHERE surah = ? AND n = ?', [surah, n]);
    return false;
  }
  await db.runAsync('INSERT INTO bookmarks (surah, n, created) VALUES (?,?,?)', [surah, n, Date.now()]);
  return true;
}

export async function getBookmarkSet(surah: number): Promise<Set<number>> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ n: number }>('SELECT n FROM bookmarks WHERE surah = ?', [surah]);
  return new Set(rows.map((r) => r.n));
}

export async function listBookmarks(): Promise<AyahRow[]> {
  const db = await getDb();
  return db.getAllAsync<AyahRow>(
    `SELECT a.* FROM bookmarks b JOIN ayahs a ON a.surah = b.surah AND a.n = b.n
     ORDER BY b.created DESC`,
  );
}

// ---------- murajaah ----------

export interface MurajaahRow {
  surah: number;
  ease: number;
  interval_days: number;
  reps: number;
  due_at: number;
}

export async function listMurajaah(): Promise<MurajaahRow[]> {
  const db = await getDb();
  return db.getAllAsync<MurajaahRow>('SELECT * FROM murajaah ORDER BY due_at');
}

export async function addMurajaah(surah: number): Promise<void> {
  const db = await getDb();
  const s = initialState();
  await db.runAsync(
    'INSERT OR IGNORE INTO murajaah (surah, ease, interval_days, reps, due_at) VALUES (?,?,?,?,?)',
    [surah, s.ease, s.intervalDays, s.reps, Date.now()],
  );
}

export async function removeMurajaah(surah: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('DELETE FROM murajaah WHERE surah = ?', [surah]);
}

export async function saveSchedule(surah: number, sch: Schedule): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    'UPDATE murajaah SET ease = ?, interval_days = ?, reps = ?, due_at = ? WHERE surah = ?',
    [sch.ease, sch.intervalDays, sch.reps, sch.dueAt, surah],
  );
}

export async function countDueMurajaah(): Promise<number> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) AS c FROM murajaah WHERE due_at <= ?', [
    Date.now(),
  ]);
  return row?.c ?? 0;
}

// ---------- activity ----------

export async function bumpActivity(day: string, seconds: number, xp: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO activity (day, seconds, xp) VALUES (?,?,?)
     ON CONFLICT(day) DO UPDATE SET seconds = seconds + excluded.seconds, xp = xp + excluded.xp`,
    [day, seconds, xp],
  );
}

export async function getActivity(days: string[]): Promise<{ day: string; seconds: number; xp: number }[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ day: string; seconds: number; xp: number }>(
    `SELECT day, seconds, xp FROM activity WHERE day IN (${days.map(() => '?').join(',')})`,
    days,
  );
  const map = new Map(rows.map((r) => [r.day, r]));
  return days.map((d) => map.get(d) ?? { day: d, seconds: 0, xp: 0 });
}

export async function resetAll(): Promise<void> {
  const db = await getDb();
  await db.execAsync(`
    DELETE FROM bookmarks; DELETE FROM murajaah; DELETE FROM activity;
    DELETE FROM kv WHERE key IN ('progress');
  `);
}
