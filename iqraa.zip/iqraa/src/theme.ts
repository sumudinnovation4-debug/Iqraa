export const colors = {
  primary: '#0D5C3F',
  primaryDark: '#094530',
  primaryLight: '#2F7D5C',
  gold: '#D4A24E',
  goldDark: '#B98630',
  goldTint: '#F8E8B6',
  greenTint: '#C8E0B0',
  cream: '#FFFEF7',
  card: '#FFFFFF',
  text: '#0B3D2B',
  muted: '#6B7F73',
  border: '#E8E2CC',
  correct: '#1E9E5A',
  correctBg: '#DDF3E6',
  wrong: '#D64545',
  wrongBg: '#FBE3E3',
  pending: '#8A9A91',
};

export const fonts = {
  arabic: 'Amiri_400Regular',
  arabicBold: 'Amiri_700Bold',
};

export const radius = { sm: 10, md: 16, lg: 22, pill: 999 };

export const shadow = {
  shadowColor: '#0D5C3F',
  shadowOpacity: 0.12,
  shadowRadius: 8,
  shadowOffset: { width: 0, height: 3 },
  elevation: 3,
} as const;
