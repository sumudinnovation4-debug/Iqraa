import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Amiri_400Regular, Amiri_700Bold, useFonts } from '@expo-google-fonts/amiri';

import { colors } from './theme';
import { TabIcon } from './components/TabIcon';
import { OfflineScreen } from './screens/OfflineScreen';
import { RootStackParams } from './nav';
import { useProgress } from './store/progress';
import { getDb } from './db/db';

import { HomeScreen } from './screens/HomeScreen';
import { PracticeScreen } from './screens/PracticeScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ReadListScreen } from './screens/ReadListScreen';
import { ReaderScreen } from './screens/ReaderScreen';
import { LearnPathScreen } from './screens/LearnPathScreen';
import { LessonScreen } from './screens/LessonScreen';
import { ReciteSelectScreen } from './screens/ReciteSelectScreen';
import { ReciteSessionScreen } from './screens/ReciteSessionScreen';
import { MurajaahHomeScreen } from './screens/MurajaahHomeScreen';
import { MurajaahSessionScreen } from './screens/MurajaahSessionScreen';

const Stack = createNativeStackNavigator<RootStackParams>();
const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: colors.cream, primary: colors.primary, card: colors.cream, text: colors.text },
};

function Tabs() {
  const insets = useSafeAreaInsets();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarShowLabel: true,
        // Add the phone's bottom inset (gesture bar / nav buttons) so icons and labels are never covered.
        tabBarStyle: {
          backgroundColor: colors.cream,
          borderTopColor: colors.border,
          height: 64 + insets.bottom,
          paddingTop: 6,
          paddingBottom: insets.bottom + 6,
        },
        tabBarLabelStyle: { fontSize: 13, fontWeight: '600' },
        tabBarIcon: ({ focused, color }) => (
          <View
            style={{
              backgroundColor: focused ? colors.goldTint : 'transparent',
              borderRadius: 14,
              paddingHorizontal: 18,
              paddingVertical: 4,
            }}
          >
            <TabIcon name={route.name} color={color} filled={focused} size={26} />
          </View>
        ),
      })}
    >
      <Tab.Screen name="Learn" component={HomeScreen} />
      <Tab.Screen name="Practice" component={PracticeScreen} />
      <Tab.Screen name="Progress" component={ProgressScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  // Icon fonts are loaded up front so every icon in the app renders on the first frame.
  const [fontsLoaded] = useFonts({
    Amiri_400Regular,
    Amiri_700Bold,
    ...Ionicons.font,
    ...MaterialCommunityIcons.font,
  });
  const ready = useProgress((s) => s.ready);
  const load = useProgress((s) => s.load);

  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    // Opens SQLite and seeds the Quran tables on first launch, then restores progress.
    setError(null);
    getDb()
      .then(load)
      .catch((e) => setError(String(e?.message ?? e)));
  }, [load, attempt]);

  if (error) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', padding: 28, gap: 16 }}>
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '800', textAlign: 'center' }}>Could not open the Quran library</Text>
        <Text style={{ color: colors.goldTint, textAlign: 'center' }}>{error}</Text>
        <Pressable
          onPress={() => setAttempt((n) => n + 1)}
          style={{ backgroundColor: colors.gold, borderRadius: 999, paddingHorizontal: 28, paddingVertical: 12 }}
        >
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 16 }}>Try again</Text>
        </Pressable>
      </View>
    );
  }

  if (!fontsLoaded || !ready) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', gap: 16, padding: 28 }}>
        <ActivityIndicator color={colors.gold} size="large" />
        <Text style={{ color: colors.goldTint, textAlign: 'center' }}>
          Preparing the Quran library. This only happens on first launch.
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <NavigationContainer theme={navTheme}>
        <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
          <Stack.Screen name="Tabs" component={Tabs} />
          <Stack.Screen name="ReadList" component={ReadListScreen} />
          <Stack.Screen name="Reader" component={ReaderScreen} />
          <Stack.Screen name="LearnPath" component={LearnPathScreen} />
          <Stack.Screen name="Lesson" component={LessonScreen} options={{ gestureEnabled: false }} />
          <Stack.Screen name="ReciteSelect" component={ReciteSelectScreen} />
          <Stack.Screen name="ReciteSession" component={ReciteSessionScreen} />
          <Stack.Screen name="MurajaahHome" component={MurajaahHomeScreen} />
          <Stack.Screen name="MurajaahSession" component={MurajaahSessionScreen} />
          <Stack.Screen name="Offline" component={OfflineScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
