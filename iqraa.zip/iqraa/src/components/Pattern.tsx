import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';
import Svg, { Polygon, Circle } from 'react-native-svg';
import { colors } from '../theme';

/** Eight-pointed Islamic star (two overlapping squares). */
export function Star8({
  size = 80,
  color = colors.gold,
  opacity = 0.35,
  style,
}: {
  size?: number;
  color?: string;
  opacity?: number;
  style?: ViewStyle;
}) {
  return (
    <View style={style} pointerEvents="none">
      <Svg width={size} height={size} viewBox="0 0 100 100" opacity={opacity}>
        <Polygon points="20,20 80,20 80,80 20,80" fill="none" stroke={color} strokeWidth={2} />
        <Polygon points="50,7.6 92.4,50 50,92.4 7.6,50" fill="none" stroke={color} strokeWidth={2} />
        <Polygon points="50,24 76,50 50,76 24,50" fill="none" stroke={color} strokeWidth={1.5} />
        <Circle cx={50} cy={50} r={6} fill="none" stroke={color} strokeWidth={1.5} />
      </Svg>
    </View>
  );
}

/** Stars tucked into the top corners of a card. */
export function CardPattern({ color = colors.gold, opacity = 0.4 }: { color?: string; opacity?: number }) {
  return (
    <>
      <Star8 size={92} color={color} opacity={opacity} style={{ position: 'absolute', top: -22, left: -22 }} />
      <Star8 size={92} color={color} opacity={opacity} style={{ position: 'absolute', top: -22, right: -22 }} />
    </>
  );
}

/** Faint geometric backdrop for whole screens. */
export function PatternBackground() {
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <Star8 size={220} opacity={0.12} style={{ position: 'absolute', top: -70, left: -80 }} />
      <Star8 size={180} opacity={0.1} style={{ position: 'absolute', top: 320, right: -90 }} />
      <Star8 size={240} opacity={0.1} style={{ position: 'absolute', bottom: -90, left: -60 }} />
    </View>
  );
}

export function Logo({ size = 64 }: { size?: number }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.26,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Star8 size={size * 0.86} opacity={1} />
    </View>
  );
}
