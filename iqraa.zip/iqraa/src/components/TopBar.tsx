import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../theme';
import { useProgress } from '../store/progress';
import { Logo } from './Pattern';

export function TopBar() {
  const insets = useSafeAreaInsets();
  const streak = useProgress((s) => s.streak);
  const gems = useProgress((s) => s.gems);
  return (
    <View style={[styles.row, { paddingTop: insets.top + 10 }]}>
      <Logo size={62} />
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Iqraa</Text>
        <Text style={styles.subtitle}>Learn & Memorize Quran</Text>
      </View>
      <View style={styles.stat}>
        <Ionicons name="flame" size={30} color="#F28C1B" />
        <Text style={styles.statText}>{streak}</Text>
      </View>
      <View style={styles.stat}>
        <MaterialCommunityIcons name="diamond-stone" size={28} color={colors.gold} />
        <Text style={styles.statText}>{gems}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 18, paddingBottom: 8 },
  title: { fontSize: 34, fontWeight: '800', color: colors.primary, lineHeight: 38 },
  subtitle: { fontSize: 13, fontWeight: '600', color: colors.text },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  statText: { fontSize: 20, fontWeight: '800', color: colors.text },
});
