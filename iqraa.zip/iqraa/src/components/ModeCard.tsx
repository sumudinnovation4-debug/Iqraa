import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, shadow } from '../theme';
import { CardPattern } from './Pattern';

export function ModeCard({
  tint,
  icon,
  title,
  note,
  subtitle,
  cta,
  onPress,
}: {
  tint: 'gold' | 'green';
  icon: React.ReactNode;
  title: string;
  note?: string;
  subtitle: string;
  cta: string;
  onPress: () => void;
}) {
  const gold = tint === 'gold';
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: gold ? colors.goldTint : colors.greenTint, opacity: pressed ? 0.92 : 1 },
      ]}
    >
      <CardPattern color={gold ? colors.gold : colors.primaryLight} opacity={0.35} />
      <View style={styles.icon}>{icon}</View>
      <Text style={styles.title}>{title}</Text>
      {note ? <Text style={styles.note}>{note}</Text> : null}
      <Text style={styles.subtitle}>{subtitle}</Text>
      <View style={[styles.cta, { backgroundColor: gold ? '#7FA774' : colors.primary }]}>
        <Text style={styles.ctaText}>{cta}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minHeight: 210,
    borderRadius: radius.lg,
    padding: 14,
    alignItems: 'center',
    overflow: 'hidden',
    ...shadow,
  },
  icon: { height: 64, alignItems: 'center', justifyContent: 'center', marginTop: 6 },
  title: { fontSize: 20, fontWeight: '800', color: colors.primary, marginTop: 6, textAlign: 'center' },
  note: { fontSize: 14, fontWeight: '700', color: colors.goldDark, textAlign: 'center' },
  subtitle: { fontSize: 14, color: colors.text, marginTop: 4, textAlign: 'center' },
  cta: { marginTop: 'auto', alignSelf: 'flex-end', paddingHorizontal: 18, paddingVertical: 7, borderRadius: radius.pill },
  ctaText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
