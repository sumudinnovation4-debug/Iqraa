import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, radius, shadow } from '../theme';
import { WordStatus } from '../lib/matcher';
import { useProgress } from '../store/progress';

export function Button({
  label,
  onPress,
  variant = 'primary',
  disabled,
  loading,
  style,
  icon,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'gold' | 'outline' | 'danger';
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  const bg =
    variant === 'primary' ? colors.primary : variant === 'gold' ? colors.gold : variant === 'danger' ? colors.wrong : 'transparent';
  const fg = variant === 'outline' ? colors.primary : '#fff';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, opacity: disabled ? 0.45 : pressed ? 0.85 : 1 },
        variant === 'outline' && { borderWidth: 2, borderColor: colors.primary },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          {icon ? <Ionicons name={icon} size={20} color={fg} /> : null}
          <Text style={[styles.btnText, { color: fg }]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function ProgressBar({
  pct,
  fill = colors.gold,
  track = colors.greenTint,
  height = 10,
}: {
  pct: number;
  fill?: string;
  track?: string;
  height?: number;
}) {
  return (
    <View style={{ height, borderRadius: height, backgroundColor: track, overflow: 'hidden' }}>
      <View
        style={{
          width: `${Math.max(0, Math.min(1, pct)) * 100}%`,
          height: '100%',
          backgroundColor: fill,
          borderRadius: height,
        }}
      />
    </View>
  );
}

/** Screen header with a back button, for screens pushed over the tabs. */
export function ScreenHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  const nav = useNavigation();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
      <Pressable onPress={() => nav.goBack()} hitSlop={12} style={styles.back}>
        <Ionicons name="chevron-back" size={24} color={colors.primary} />
      </Pressable>
      <View style={{ flex: 1 }}>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? <Text style={styles.headerSub}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function Chip({ label, active, onPress }: { label: string; active?: boolean; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.chip, active && { backgroundColor: colors.primary, borderColor: colors.primary }]}
    >
      <Text style={{ color: active ? '#fff' : colors.primary, fontWeight: '600' }}>{label}</Text>
    </Pressable>
  );
}

const WORD_COLOR: Record<WordStatus | 'plain', string> = {
  plain: colors.text,
  pending: colors.pending,
  correct: colors.correct,
  wrong: colors.wrong,
};

/** Arabic ayah rendered word by word so each word can be coloured. */
export function ArabicWords({
  words,
  statuses,
  size = 34,
  hidden,
  onWordPress,
  style,
}: {
  words: string[];
  statuses?: WordStatus[];
  size?: number;
  hidden?: Set<number>;
  onWordPress?: (i: number) => void;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View style={[{ flexDirection: 'row-reverse', flexWrap: 'wrap', justifyContent: 'center', gap: 6 }, style]}>
      {words.map((w, i) => {
        const st = statuses ? statuses[i] : 'plain';
        const isHidden = hidden?.has(i);
        const wordStyle: TextStyle = {
          fontFamily: fonts.arabic,
          fontSize: size,
          lineHeight: size * 1.9,
          color: WORD_COLOR[st],
          writingDirection: 'rtl',
        };
        const bg =
          st === 'correct' ? colors.correctBg : st === 'wrong' ? colors.wrongBg : 'transparent';
        return (
          <Pressable
            key={i}
            disabled={!onWordPress}
            onPress={() => onWordPress?.(i)}
            style={{ backgroundColor: bg, borderRadius: 10, paddingHorizontal: 6 }}
          >
            <Text style={wordStyle}>{isHidden ? '••••' : w}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** English and/or Hausa translation, following the user's Translation setting. */
export function Translation({
  en,
  ha,
  align = 'center',
  size = 15,
}: {
  en: string;
  ha: string;
  align?: 'center' | 'left';
  size?: number;
}) {
  const mode = useProgress((s) => s.translation);
  return (
    <View style={{ gap: 6 }}>
      {mode !== 'ha' ? <Text style={{ fontSize: size, color: colors.text, textAlign: align }}>{en}</Text> : null}
      {mode !== 'en' ? (
        <Text style={{ fontSize: size, color: colors.primaryLight, textAlign: align, fontStyle: 'italic' }}>{ha}</Text>
      ) : null}
    </View>
  );
}

export function arabicStyle(size = 30): TextStyle {
  return { fontFamily: fonts.arabic, fontSize: size, lineHeight: size * 1.9, color: colors.text, textAlign: 'center', writingDirection: 'rtl' };
}

const styles = StyleSheet.create({
  btn: { minHeight: 50, borderRadius: radius.pill, paddingHorizontal: 22, alignItems: 'center', justifyContent: 'center' },
  btnText: { fontSize: 16, fontWeight: '700' },
  card: { backgroundColor: colors.card, borderRadius: radius.lg, padding: 16, borderWidth: 1, borderColor: colors.border, ...shadow },
  header: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingBottom: 10, backgroundColor: colors.cream },
  back: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.goldTint },
  headerTitle: { fontSize: 20, fontWeight: '800', color: colors.text },
  headerSub: { fontSize: 13, color: colors.muted },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.pill, borderWidth: 1.5, borderColor: colors.primary, backgroundColor: colors.cream },
});
