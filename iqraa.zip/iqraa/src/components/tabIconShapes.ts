// Geometry for the bottom-tab icons (24 x 24 grid). Kept as plain data so the same shapes are
// used by the app (react-native-svg) and by the preview script.
//   fill: true   -> filled with the icon colour when the tab is selected
//   inner: true  -> detail line drawn on top; uses the background colour when the shape is filled
export type Shape =
  | { kind: 'path'; d: string; fill?: boolean; inner?: boolean; dot?: boolean }
  | { kind: 'circle'; cx: number; cy: number; r: number; fill?: boolean; inner?: boolean; dot?: boolean }
  | { kind: 'rect'; x: number; y: number; w: number; h: number; rx: number; fill?: boolean };

export const TAB_SHAPES: Record<string, Shape[]> = {
  // Open book
  Learn: [
    {
      kind: 'path',
      fill: true,
      d: 'M12 6.6C10.4 5.4 8.2 4.8 5.4 4.8c-.9 0-1.7.1-2.4.3v12.6c.7-.2 1.5-.3 2.4-.3 2.8 0 5 .6 6.6 1.8 1.6-1.2 3.8-1.8 6.6-1.8.9 0 1.7.1 2.4.3V5.1c-.7-.2-1.5-.3-2.4-.3-2.8 0-5 .6-6.6 1.8z',
    },
    { kind: 'path', inner: true, d: 'M12 6.8v12.4' },
  ],
  // Target
  Practice: [
    { kind: 'circle', cx: 12, cy: 12, r: 8.5, fill: true },
    { kind: 'circle', cx: 12, cy: 12, r: 4.6, inner: true },
    { kind: 'circle', cx: 12, cy: 12, r: 1.4, inner: true, dot: true },
    { kind: 'path', d: 'M12 1.8v3M12 19.2v3M1.8 12h3M19.2 12h3' },
  ],
  // Bar chart
  Progress: [
    { kind: 'rect', x: 3.5, y: 12, w: 4.4, h: 8.5, rx: 1.2, fill: true },
    { kind: 'rect', x: 9.8, y: 4.5, w: 4.4, h: 16, rx: 1.2, fill: true },
    { kind: 'rect', x: 16.1, y: 8.5, w: 4.4, h: 12, rx: 1.2, fill: true },
  ],
  // Person
  Profile: [
    { kind: 'circle', cx: 12, cy: 7.8, r: 4, fill: true },
    { kind: 'path', fill: true, d: 'M4 20.5c0-4.1 3.5-6.6 8-6.6s8 2.5 8 6.6z' },
  ],
};
