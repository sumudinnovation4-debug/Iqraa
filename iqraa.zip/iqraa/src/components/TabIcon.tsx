import React from 'react';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { colors } from '../theme';
import { TAB_SHAPES } from './tabIconShapes';

/** Bottom-tab icon drawn with SVG shapes, so it never depends on an icon font loading. */
export function TabIcon({
  name,
  color,
  filled,
  size = 26,
  background = colors.goldTint,
}: {
  name: string;
  color: string;
  filled: boolean;
  size?: number;
  /** Colour behind the icon, used for detail lines drawn on a filled shape. */
  background?: string;
}) {
  const shapes = TAB_SHAPES[name] ?? [];
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      {shapes.map((s, i) => {
        const strokeProps = { stroke: color, strokeWidth: 1.9, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
        if (s.kind === 'rect') {
          return (
            <Rect
              key={i}
              x={s.x}
              y={s.y}
              width={s.w}
              height={s.h}
              rx={s.rx}
              fill={filled && s.fill ? color : 'none'}
              {...strokeProps}
            />
          );
        }
        // Detail shapes sit on top of a filled shape: draw them in the background colour then.
        const detail = filled && s.inner;
        const stroke = detail ? background : color;
        const fill = s.dot ? (detail ? background : color) : filled && s.fill ? color : 'none';
        if (s.kind === 'circle') {
          return (
            <Circle
              key={i}
              cx={s.cx}
              cy={s.cy}
              r={s.r}
              fill={fill}
              stroke={stroke}
              strokeWidth={1.9}
            />
          );
        }
        return <Path key={i} d={s.d} fill={fill} stroke={stroke} strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" />;
      })}
    </Svg>
  );
}
