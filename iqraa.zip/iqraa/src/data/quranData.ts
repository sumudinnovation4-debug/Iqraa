// Quran content for the whole app. The text lives in quran.json:
//  - this repo ships Al-Fatiha and Al-Ikhlas (so the app runs out of the box);
//  - `npm run build:data` (also run by the upload.yml workflow) replaces it with the
//    full Quran: Uthmani Arabic, English (Sahih International), Hausa (Gumi).
import data from './quran.json';
import { tajweedFor } from './tajweed';

export interface Ayah {
  n: number;
  ar: string;
  en: string;
  ha: string;
  juz: number;
}

export interface Surah {
  id: number;
  ar: string;
  en: string;
  meaning: string;
  juz: number;
  place: string;
  ayahs: Ayah[];
}

export const QURAN: Surah[] = (data as { surahs: Surah[] }).surahs;

const BY_ID = new Map<number, Surah>(QURAN.map((s) => [s.id, s]));

export const AYAH_TOTAL = QURAN.reduce((n, s) => n + s.ayahs.length, 0);

export function findSurah(id: number): Surah | undefined {
  return BY_ID.get(id);
}

export function getSurah(id: number): Surah {
  const s = BY_ID.get(id);
  if (!s) throw new Error(`Surah ${id} is not bundled in this build`);
  return s;
}

export function getAyah(surahId: number, n: number): Ayah {
  const s = getSurah(surahId);
  const a = s.ayahs[n - 1]?.n === n ? s.ayahs[n - 1] : s.ayahs.find((x) => x.n === n);
  if (!a) throw new Error(`Ayah ${surahId}:${n} not found`);
  return a;
}

export { tajweedFor };

export const BISMILLAH = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';
