import { QURAN, findSurah, getSurah, tajweedFor } from './quranData';
import { displayWords } from '../lib/arabic';

export interface AyahRef {
  s: number;
  a: number;
}

export type Lang = 'en' | 'ha';

export type Step =
  | { kind: 'teach'; title: string; arabic?: string; body: string; bodyHa?: string; audio?: AyahRef; tajweed?: string[] }
  | { kind: 'mcq'; prompt: string; arabic?: string; options: string[]; answer: number; arabicOptions?: boolean }
  | { kind: 'fill'; ref: AyahRef; hide: number; options: string[] }
  | { kind: 'order'; ref: AyahRef };

export interface Lesson {
  id: string;
  title: string;
  subtitle: string;
  steps: Step[];
  /** Surah that counts as learned (added to Murajaah) once this lesson is done. */
  memorizes?: number;
}

/** Cheap description of a lesson; steps are only generated when it is opened. */
export interface LessonMeta {
  id: string;
  title: string;
  subtitle: string;
  build: (lang: Lang) => Lesson;
}

export interface Unit {
  id: string;
  title: string;
  lessons: LessonMeta[];
}

// ---------- helpers ----------

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Put the right answer at a random position among distractors. */
function withAnswer(correct: string, distractors: string[]): { options: string[]; answer: number } {
  const options = shuffle([correct, ...distractors]);
  return { options, answer: options.indexOf(correct) };
}

// ---------- Noorani Qaida ----------

const LETTERS: { ch: string; name: string; sound: string }[] = [
  { ch: 'ا', name: 'Alif', sound: 'A soft "a"; it also stretches other vowels.' },
  { ch: 'ب', name: 'Baa', sound: 'Like the "b" in "bat".' },
  { ch: 'ت', name: 'Taa', sound: 'Like the "t" in "top".' },
  { ch: 'ث', name: 'Thaa', sound: 'Like the "th" in "think".' },
  { ch: 'ج', name: 'Jeem', sound: 'Like the "j" in "jam".' },
  { ch: 'ح', name: 'Haa', sound: 'A deep, breathy "h" from the middle of the throat.' },
  { ch: 'خ', name: 'Khaa', sound: 'Like the "ch" in Scottish "loch".' },
];

function letterLesson(id: string, title: string, subtitle: string, chars: string[]): Lesson {
  const picked = LETTERS.filter((l) => chars.includes(l.ch));
  const steps: Step[] = [];
  for (const l of picked) {
    steps.push({ kind: 'teach', title: `${l.name}`, arabic: l.ch, body: l.sound });
  }
  for (const l of shuffle(picked)) {
    const others = shuffle(LETTERS.filter((x) => x.ch !== l.ch)).slice(0, 3).map((x) => x.name);
    steps.push({ kind: 'mcq', prompt: 'What is the name of this letter?', arabic: l.ch, ...withAnswer(l.name, others) });
  }
  for (const l of shuffle(picked)) {
    const others = shuffle(LETTERS.filter((x) => x.ch !== l.ch)).slice(0, 3).map((x) => x.ch);
    steps.push({
      kind: 'mcq',
      prompt: `Which letter is ${l.name}?`,
      arabicOptions: true,
      ...withAnswer(l.ch, others),
    });
  }
  return { id, title, subtitle, steps };
}

function harakatLesson(): Lesson {
  return {
    id: 'qaida-3',
    title: 'Short vowels',
    subtitle: 'Fatha, kasra, damma',
    steps: [
      { kind: 'teach', title: 'Fatha  َ', arabic: 'بَ', body: 'A small slash above the letter gives an "a" sound: ba.' },
      { kind: 'teach', title: 'Kasra  ِ', arabic: 'بِ', body: 'A small slash below the letter gives an "i" sound: bi.' },
      { kind: 'teach', title: 'Damma  ُ', arabic: 'بُ', body: 'A small waw above the letter gives a "u" sound: bu.' },
      { kind: 'mcq', prompt: 'How do you read this?', arabic: 'بَ', ...withAnswer('ba', ['bi', 'bu', 'ta']) },
      { kind: 'mcq', prompt: 'How do you read this?', arabic: 'بِ', ...withAnswer('bi', ['ba', 'bu', 'ti']) },
      { kind: 'mcq', prompt: 'How do you read this?', arabic: 'بُ', ...withAnswer('bu', ['ba', 'bi', 'tu']) },
      { kind: 'mcq', prompt: 'How do you read this?', arabic: 'تَ', ...withAnswer('ta', ['ti', 'tu', 'ba']) },
      { kind: 'mcq', prompt: 'How do you read this?', arabic: 'ثُ', ...withAnswer('thu', ['tha', 'thi', 'bu']) },
    ],
  };
}

// ---------- Surah lessons ----------

const CHUNK = 4; // ayahs per lesson, about five minutes

/** Words from this surah and its neighbours, used as wrong answers for "missing word". */
function distractorWords(surahId: number, exclude: string[], count = 3): string[] {
  const pool = new Set<string>();
  for (const id of [surahId, surahId - 1, surahId + 1, surahId + 2, surahId - 2]) {
    const s = findSurah(id);
    if (!s) continue;
    for (const a of s.ayahs.slice(0, 40)) for (const w of displayWords(a.ar)) pool.add(w);
  }
  return shuffle([...pool].filter((w) => !exclude.includes(w))).slice(0, count);
}

function surahLesson(
  id: string,
  surahId: number,
  from: number,
  to: number,
  lang: Lang,
  memorizes?: number,
): Lesson {
  const surah = getSurah(surahId);
  const range = surah.ayahs.filter((a) => a.n >= from && a.n <= to);
  const meaning = (a: { en: string; ha: string }) => (lang === 'ha' ? a.ha : a.en);
  const steps: Step[] = [];

  for (const a of range) {
    steps.push({
      kind: 'teach',
      title: `${surah.en} · Ayah ${a.n}`,
      arabic: a.ar,
      body: a.en,
      bodyHa: a.ha,
      audio: { s: surahId, a: a.n },
      tajweed: tajweedFor(surahId, a.n),
    });
  }

  // Meaning quiz: wrong answers come from other ayahs of this surah, topped up from neighbours.
  const otherPool = shuffle(
    [surah, ...[surahId - 1, surahId + 1].map(findSurah)].flatMap((s) => (s ? s.ayahs : [])),
  );
  for (const a of range) {
    const correct = meaning(a);
    const wrong = otherPool
      .filter((x) => !(x.n === a.n && surah.ayahs.includes(x)) && meaning(x) !== correct)
      .slice(0, 2)
      .map(meaning);
    steps.push({ kind: 'mcq', prompt: 'What does this ayah mean?', arabic: a.ar, ...withAnswer(correct, wrong) });
  }

  for (const a of range) {
    const words = displayWords(a.ar);
    if (words.length < 2) continue;
    const hide = Math.floor(Math.random() * words.length);
    const distractors = distractorWords(surahId, words);
    steps.push({ kind: 'fill', ref: { s: surahId, a: a.n }, hide, options: shuffle([words[hide], ...distractors]) });
  }

  for (const a of range) {
    const n = displayWords(a.ar).length;
    if (n >= 2 && n <= 12) steps.push({ kind: 'order', ref: { s: surahId, a: a.n } });
  }

  return {
    id,
    title: `Ayahs ${from === to ? from : `${from}-${to}`}`,
    subtitle: surah.en,
    steps,
    memorizes,
  };
}

function surahUnit(surahId: number, prefix = ''): Unit | null {
  const surah = findSurah(surahId);
  if (!surah) return null;
  const total = surah.ayahs.length;
  const lessons: LessonMeta[] = [];
  for (let from = 1, i = 1; from <= total; from += CHUNK, i++) {
    const to = Math.min(total, from + CHUNK - 1);
    const last = to === total;
    lessons.push({
      id: `s${surahId}-${i}`,
      title: `Ayahs ${from === to ? from : `${from}-${to}`}`,
      subtitle: surah.en,
      build: (lang) => surahLesson(`s${surahId}-${i}`, surahId, from, to, lang, last ? surahId : undefined),
    });
  }
  return { id: `surah-${surahId}`, title: `${prefix}${surah.en}`, lessons };
}

// Al-Fatiha, then Juz Amma from the shortest-and-most-recited end: 112, 113, 114, then 111 down to 78.
const JUZ_AMMA_ORDER = [112, 113, 114, ...Array.from({ length: 34 }, (_, k) => 111 - k)];

export function buildUnits(): Unit[] {
  const qaida: Unit = {
    id: 'qaida',
    title: 'Noorani Qaida',
    lessons: [
      { id: 'qaida-1', title: 'Letters I', subtitle: 'ا ب ت ث', build: () => letterLesson('qaida-1', 'Letters I', 'ا ب ت ث', ['ا', 'ب', 'ت', 'ث']) },
      { id: 'qaida-2', title: 'Letters II', subtitle: 'ج ح خ', build: () => letterLesson('qaida-2', 'Letters II', 'ج ح خ', ['ج', 'ح', 'خ']) },
      { id: 'qaida-3', title: 'Short vowels', subtitle: 'Fatha, kasra, damma', build: () => harakatLesson() },
    ],
  };
  const units: Unit[] = [qaida];
  const fatiha = surahUnit(1);
  if (fatiha) units.push(fatiha);
  for (const id of JUZ_AMMA_ORDER) {
    const u = surahUnit(id, 'Juz Amma · ');
    if (u) units.push(u);
  }
  return units;
}

export function findLesson(id: string, lang: Lang = 'en'): Lesson | undefined {
  for (const u of buildUnits()) {
    const l = u.lessons.find((x) => x.id === id);
    if (l) return l.build(lang);
  }
  return undefined;
}

export const SURAH_COUNT = QURAN.length;
