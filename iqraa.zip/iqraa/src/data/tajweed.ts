// Short, hand-checked tajweed notes, keyed "surah:ayah". Only some ayahs have notes;
// add more here as you verify them. Everything else shows no tajweed box.
export const TAJWEED: Record<string, string[]> = {
  "1:1": [
    "The Lam in ٱللَّهِ is light (tarqeeq) after the kasra of بِسْمِ.",
    "ٱلرَّحْمَٰنِ and ٱلرَّحِيمِ: madd asli, stretch 2 counts on the long vowel.",
  ],
  "1:2": [
    "The Lam in لِلَّهِ is light after the kasra.",
    "ٱلْعَٰلَمِينَ: madd asli on the ʿayn-alef; when you stop, the final مِينَ takes madd ʿarid lis-sukun (2, 4 or 6 counts).",
  ],
  "1:3": [
    "ٱلرَّحْمَٰنِ: madd asli on the dagger alef (2 counts).",
    "When you stop on ٱلرَّحِيمِ, madd ʿarid lis-sukun applies.",
  ],
  "1:4": [
    "مَٰلِكِ: madd asli on the dagger alef (2 counts).",
    "When you stop on ٱلدِّينِ, madd ʿarid lis-sukun applies.",
  ],
  "1:5": [
    "إِيَّاكَ: shadda on the ya, then madd asli on the alef (2 counts).",
    "When you stop on نَسْتَعِينُ, madd ʿarid lis-sukun applies.",
  ],
  "1:6": [
    "ٱلصِّرَٰطَ: ص is a heavy letter (isti‘la); keep it full, not like س.",
    "ٱلْمُسْتَقِيمَ: ق is heavy; madd ʿarid lis-sukun when you stop.",
  ],
  "1:7": [
    "أَنْعَمْتَ: noon sakin before ع is izhar halqi (pronounce the noon clearly).",
    "عَلَيْهِمْ غَيْرِ: mim sakin before غ is izhar shafawi (clear mim).",
    "ٱلْمَغْضُوبِ: غ and ض are heavy letters.",
    "ٱلضَّآلِّينَ: madd lazim kilmi muthaqqal, stretch 6 counts on the آ.",
  ],
  "112:1": [
    "The Lam in ٱللَّهُ is heavy (tafkhim) after the fatha of هُوَ.",
    "When you stop on أَحَدٌ, the د is silent and carries qalqalah (a slight bounce).",
  ],
  "112:2": [
    "Starting the ayah, the Lam in ٱللَّهُ is heavy.",
    "ٱلصَّمَدُ: ص is heavy; qalqalah on the د when you stop.",
  ],
  "112:3": [
    "لَمْ يَلِدْ: mim sakin before ي is izhar shafawi (clear mim).",
    "يَلِدْ and يُولَدْ end in د with sukoon: qalqalah.",
    "يُولَدْ: madd asli on the waw (2 counts).",
  ],
  "112:4": [
    "يَكُن لَّهُۥ: noon sakin before ل is idgham bila ghunna (merge without nasal sound).",
    "لَّهُۥ: madd silah sughra on the pronoun ha (2 counts).",
    "كُفُوًا أَحَدٌ: tanween before أ is izhar halqi (clear).",
    "When you stop on أَحَدٌ, qalqalah on the د.",
  ],
};

export function tajweedFor(surah: number, ayah: number): string[] {
  return TAJWEED[`${surah}:${ayah}`] ?? [];
}
