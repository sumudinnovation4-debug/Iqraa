import { create } from 'zustand';
import { bumpActivity, getActivity, getKv, resetAll, setKv } from '../db/db';
import { dayKey, daysBetween } from '../lib/dates';

const XP_PER_LEVEL = 100;

export function levelFromXp(xp: number) {
  const level = Math.floor(xp / XP_PER_LEVEL) + 1;
  const into = xp % XP_PER_LEVEL;
  return { level, into, needed: XP_PER_LEVEL, pct: into / XP_PER_LEVEL };
}

export type TranslationMode = 'both' | 'en' | 'ha';

interface Persisted {
  translation: TranslationMode;
  name: string;
  xp: number;
  gems: number;
  streak: number;
  lastActive: string | null;
  goalMinutes: number;
  completed: Record<string, number>; // lessonId -> stars (1..3)
}

interface ProgressState extends Persisted {
  ready: boolean;
  today: string;
  todaySeconds: number;
  load: () => Promise<void>;
  addReward: (xp: number, gems?: number) => void;
  addSeconds: (seconds: number) => void;
  completeLesson: (id: string, stars: number) => void;
  setName: (name: string) => void;
  setGoal: (minutes: number) => void;
  setTranslation: (mode: TranslationMode) => void;
  reset: () => Promise<void>;
}

const defaults: Persisted = {
  translation: 'both',
  name: 'Ahmad',
  xp: 0,
  gems: 0,
  streak: 0,
  lastActive: null,
  goalMinutes: 15,
  completed: {},
};

let persistTimer: ReturnType<typeof setTimeout> | null = null;

function schedulePersist(get: () => ProgressState) {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    const { translation, name, xp, gems, streak, lastActive, goalMinutes, completed } = get();
    const data: Persisted = { translation, name, xp, gems, streak, lastActive, goalMinutes, completed };
    setKv('progress', JSON.stringify(data)).catch(() => {});
  }, 400);
}

export const useProgress = create<ProgressState>((set, get) => {
  /** Keep the streak in step with the calendar; call on any activity. */
  const touchStreak = () => {
    const today = dayKey();
    const { lastActive, streak } = get();
    if (lastActive === today) return;
    const next = lastActive && daysBetween(lastActive, today) === 1 ? streak + 1 : 1;
    set({ streak: next, lastActive: today });
  };

  return {
    ...defaults,
    ready: false,
    today: dayKey(),
    todaySeconds: 0,

    load: async () => {
      let saved: Partial<Persisted> = {};
      try {
        const raw = await getKv('progress');
        if (raw) saved = JSON.parse(raw);
      } catch {}
      const today = dayKey();
      const [row] = await getActivity([today]);
      const merged = { ...defaults, ...saved };
      // A missed day breaks the streak even before new activity happens.
      if (merged.lastActive && daysBetween(merged.lastActive, today) > 1) merged.streak = 0;
      set({ ...merged, today, todaySeconds: row?.seconds ?? 0, ready: true });
    },

    addReward: (xp, gems = 0) => {
      touchStreak();
      set((s) => ({ xp: s.xp + xp, gems: s.gems + gems }));
      bumpActivity(dayKey(), 0, xp).catch(() => {});
      schedulePersist(get);
    },

    addSeconds: (seconds) => {
      touchStreak();
      const today = dayKey();
      set((s) => ({
        today,
        todaySeconds: (s.today === today ? s.todaySeconds : 0) + seconds,
      }));
      bumpActivity(today, seconds, 0).catch(() => {});
      schedulePersist(get);
    },

    completeLesson: (id, stars) => {
      set((s) => ({ completed: { ...s.completed, [id]: Math.max(s.completed[id] ?? 0, stars) } }));
      schedulePersist(get);
    },

    setName: (name) => {
      set({ name });
      schedulePersist(get);
    },

    setGoal: (goalMinutes) => {
      set({ goalMinutes });
      schedulePersist(get);
    },

    setTranslation: (translation) => {
      set({ translation });
      schedulePersist(get);
    },

    reset: async () => {
      await resetAll();
      set({ ...defaults, todaySeconds: 0, today: dayKey() });
    },
  };
});
