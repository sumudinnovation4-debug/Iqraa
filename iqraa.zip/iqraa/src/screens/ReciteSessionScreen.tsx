import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, PermissionsAndroid, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius } from '../theme';
import { getSurah } from '../data/quranData';
import { displayWords, expectedWords } from '../lib/arabic';
import { AlignResult, WordStatus, alignRecitation } from '../lib/matcher';
import { playAyah, prefetchAyahAudio, stopAudio } from '../lib/audio';
import {
  Listener,
  MODELS,
  ModelKey,
  downloadModel,
  loadModel,
  preferredModel,
  startListening,
} from '../lib/whisper';
import { useProgress } from '../store/progress';
import { ArabicWords, Button, Card, Chip, ProgressBar, ScreenHeader, Translation } from '../components/ui';
import { ScreenProps } from '../nav';
import { useSessionTimer } from '../hooks';

type Phase = 'idle' | 'listening' | 'correcting' | 'repeat' | 'ayahDone' | 'surahDone';
type ModelState = 'checking' | 'missing' | 'downloading' | 'loading' | 'ready' | 'error';

export function ReciteSessionScreen({ route }: ScreenProps<'ReciteSession'>) {
  const surah = useMemo(() => getSurah(route.params.surah), [route.params.surah]);
  const nav = useNavigation<any>();
  const addReward = useProgress((s) => s.addReward);
  useSessionTimer();

  const [ayahIdx, setAyahIdx] = useState(0);
  const ayah = surah.ayahs[ayahIdx];

  // While online, quietly save this ayah's audio and the next one, so the correction
  // audio is already on the phone when it is needed (and works offline later).
  useEffect(() => {
    prefetchAyahAudio(surah.id, ayah.n);
    const upcoming = surah.ayahs[ayahIdx + 1];
    if (upcoming) prefetchAyahAudio(surah.id, upcoming.n);
    setAudioMissing(false);
  }, [surah, ayahIdx, ayah.n]);
  const words = useMemo(() => displayWords(ayah.ar), [ayah]);
  const expected = useMemo(() => expectedWords(ayah.ar), [ayah]);

  const [statuses, setStatuses] = useState<WordStatus[]>(() => expected.map(() => 'pending'));
  const [phase, setPhase] = useState<Phase>('idle');
  const [message, setMessage] = useState('Tap the microphone and recite this ayah.');
  const [model, setModel] = useState<ModelState>('checking');
  const [modelChoice, setModelChoice] = useState<ModelKey>('base');
  const [progress, setProgress] = useState(0);
  const [mistakes, setMistakes] = useState(0); // for the current ayah
  const [totalMistakes, setTotalMistakes] = useState(0);
  const [cleanAyahs, setCleanAyahs] = useState(0);
  const [doneAyahs, setDoneAyahs] = useState(0);
  const [earned, setEarned] = useState(0);
  const [jump, setJump] = useState('');
  const [audioMissing, setAudioMissing] = useState(false);

  // Refs avoid stale closures inside the streaming callback.
  const phaseRef = useRef<Phase>('idle');
  const listenerRef = useRef<Listener | null>(null);
  const lastText = useRef('');
  const demoTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const mistakesRef = useRef(0);
  const expectedRef = useRef(expected);
  expectedRef.current = expected;

  const setPhaseBoth = (p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  // ---------- model ----------
  const prepareModel = useCallback(async () => {
    setModel('checking');
    try {
      const key = await preferredModel();
      if (!key) {
        setModel('missing');
        return;
      }
      setModel('loading');
      await loadModel(key);
      setModel('ready');
    } catch {
      setModel('error');
    }
  }, []);

  useEffect(() => {
    prepareModel();
    return () => {
      if (demoTimer.current) clearInterval(demoTimer.current);
      listenerRef.current?.stop().catch(() => {});
      stopAudio();
    };
  }, [prepareModel]);

  const download = async () => {
    setModel('downloading');
    setProgress(0);
    try {
      await downloadModel(modelChoice, setProgress);
      await prepareModel();
    } catch (e: any) {
      setModel('missing');
      Alert.alert('Download failed', e?.message ?? 'Check your connection and try again.');
    }
  };

  // ---------- recitation flow ----------
  const stopListener = async () => {
    if (demoTimer.current) {
      clearInterval(demoTimer.current);
      demoTimer.current = null;
    }
    const l = listenerRef.current;
    listenerRef.current = null;
    if (l) await l.stop().catch(() => {});
  };

  const onSuccess = async (res: AlignResult) => {
    setPhaseBoth('ayahDone');
    await stopListener();
    setStatuses(res.statuses.map(() => 'correct'));
    const clean = mistakesRef.current === 0;
    const xp = clean ? 15 : 10;
    addReward(xp, 1);
    setEarned((e) => e + xp);
    setDoneAyahs((d) => d + 1);
    if (clean) setCleanAyahs((c) => c + 1);
    setMessage(clean ? 'Mashaallah! Perfect on the first try.' : 'Well done. Corrected and repeated.');
  };

  const onMistake = async (res: AlignResult) => {
    if (phaseRef.current !== 'listening') return;
    setPhaseBoth('correcting');
    await stopListener();
    setStatuses(res.statuses);
    mistakesRef.current += 1;
    setMistakes(mistakesRef.current);
    setTotalMistakes((t) => t + 1);
    const wrongWord = words[res.firstWrong];
    setMessage(`Check the word ${wrongWord}. Listen to the correct recitation...`);
    let audioOk = true;
    try {
      await playAyah(surah.id, ayah.n);
    } catch {
      audioOk = false;
    }
    setAudioMissing(!audioOk);
    setPhaseBoth('repeat');
    setMessage(
      audioOk
        ? 'Now repeat the ayah. Tap the microphone when ready.'
        : "The correct audio isn't saved offline. Read the ayah above, then repeat it.",
    );
  };

  const handleText = (text: string) => {
    if (phaseRef.current !== 'listening') return;
    lastText.current = text;
    const res = alignRecitation(expectedRef.current, text, false);
    setStatuses(res.statuses);
    if (res.firstWrong >= 0) onMistake(res);
    else if (res.complete) onSuccess(res);
  };

  const beginAttempt = () => {
    stopAudio();
    lastText.current = '';
    setStatuses(expected.map(() => 'pending'));
    setPhaseBoth('listening');
    setMessage('Listening... recite the ayah.');
  };

  const requestMic = async (): Promise<boolean> => {
    if (Platform.OS !== 'android') return true;
    const r = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
    return r === PermissionsAndroid.RESULTS.GRANTED;
  };

  const startMic = async () => {
    if (model !== 'ready') return;
    if (!(await requestMic())) {
      Alert.alert('Microphone needed', 'Allow microphone access so Iqraa can hear your recitation.');
      return;
    }
    beginAttempt();
    try {
      listenerRef.current = await startListening((text) => handleText(text));
    } catch (e: any) {
      setPhaseBoth('idle');
      setMessage(e?.message ?? 'Could not start the microphone.');
    }
  };

  const stopMic = async () => {
    if (phaseRef.current !== 'listening') return;
    await stopListener();
    const text = lastText.current;
    if (!text.trim()) {
      setPhaseBoth('idle');
      setMessage("I didn't hear anything. Try again a little closer to the microphone.");
      return;
    }
    const res = alignRecitation(expected, text, true);
    phaseRef.current = 'listening'; // let the handlers below run once
    if (res.complete) await onSuccess(res);
    else await onMistake(res);
  };

  /** Scripted attempt so the correction flow can be tried without a microphone. */
  const runDemo = () => {
    if (words.length < 2) {
      Alert.alert('Demo', 'Pick an ayah with at least two words.');
      return;
    }
    beginAttempt();
    const spoken = [...expected];
    if (mistakesRef.current === 0) spoken[Math.min(1, spoken.length - 1)] = 'كتاب'; // first try: one deliberate error
    let k = 0;
    demoTimer.current = setInterval(() => {
      k++;
      handleText(spoken.slice(0, k).join(' '));
      if (k >= spoken.length && demoTimer.current) {
        clearInterval(demoTimer.current);
        demoTimer.current = null;
        // Flush the last word like a recogniser finishing.
        setTimeout(() => {
          if (phaseRef.current === 'listening') {
            const res = alignRecitation(expectedRef.current, spoken.join(' '), true);
            if (res.complete) onSuccess(res);
            else onMistake(res);
          }
        }, 300);
      }
    }, 700);
  };

  const hearIt = async () => {
    if (phaseRef.current === 'listening') return;
    try {
      await playAyah(surah.id, ayah.n);
    } catch (e: any) {
      Alert.alert('Audio unavailable', e?.message ?? 'Could not load audio.');
    }
  };

  const next = () => {
    stopAudio();
    mistakesRef.current = 0;
    setMistakes(0);
    if (ayahIdx + 1 >= surah.ayahs.length) {
      // Completion bonus only when every ayah of the surah was actually recited.
      if (doneAyahs >= surah.ayahs.length) {
        addReward(20, 5);
        setEarned((e) => e + 20);
      }
      setPhaseBoth('surahDone');
      return;
    }
    const nextAyah = surah.ayahs[ayahIdx + 1];
    setAyahIdx(ayahIdx + 1);
    setStatuses(expectedWords(nextAyah.ar).map(() => 'pending'));
    setPhaseBoth('idle');
    setMessage('Tap the microphone and recite this ayah.');
  };

  const skip = () => {
    stopListener();
    next();
  };

  /** Jump straight to an ayah (useful for long surahs). */
  const goTo = async () => {
    const n = parseInt(jump, 10);
    if (!Number.isFinite(n) || n < 1 || n > surah.ayahs.length) {
      Alert.alert('Go to ayah', `Enter a number from 1 to ${surah.ayahs.length}.`);
      return;
    }
    await stopListener();
    stopAudio();
    mistakesRef.current = 0;
    setMistakes(0);
    setAyahIdx(n - 1);
    setStatuses(expectedWords(surah.ayahs[n - 1].ar).map(() => 'pending'));
    setPhaseBoth('idle');
    setMessage('Tap the microphone and recite this ayah.');
    setJump('');
  };

  // ---------- render ----------
  if (phase === 'surahDone') {
    return (
      <View style={{ flex: 1, backgroundColor: colors.cream, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 }}>
        <Ionicons name="trophy" size={72} color={colors.gold} />
        <Text style={{ fontSize: 28, fontWeight: '800', color: colors.primary }}>{surah.en} complete</Text>
        <Text style={{ fontSize: 17, color: colors.text, textAlign: 'center' }}>
          {cleanAyahs}/{doneAyahs} ayahs perfect on the first try · {totalMistakes} correction
          {totalMistakes === 1 ? '' : 's'} · +{earned} XP
        </Text>
        <Button label="Done" onPress={() => nav.goBack()} style={{ alignSelf: 'stretch' }} />
      </View>
    );
  }

  const showStatuses = phase !== 'idle';
  const listening = phase === 'listening';
  const busy = phase === 'correcting';

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title={surah.en} subtitle={`Ayah ${ayah.n} of ${surah.ayahs.length}`} />
      <View style={{ paddingHorizontal: 16 }}>
        <ProgressBar pct={ayahIdx / surah.ayahs.length} fill={colors.primary} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        {model !== 'ready' ? (
          <Card style={{ gap: 10 }}>
            <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text }}>Set up offline listening</Text>
            {model === 'checking' || model === 'loading' ? (
              <Text style={{ color: colors.muted }}>{model === 'checking' ? 'Checking...' : 'Loading the speech model...'}</Text>
            ) : model === 'downloading' ? (
              <>
                <Text style={{ color: colors.muted }}>Downloading {MODELS[modelChoice].label} model... {Math.round(progress * 100)}%</Text>
                <ProgressBar pct={progress} />
              </>
            ) : (
              <>
                <Text style={{ color: colors.muted }}>
                  {model === 'error'
                    ? 'The speech model could not be loaded. Re-download it or try the demo below.'
                    : 'Recite Mode needs a one-time download of a speech model. After that it works fully offline and nothing is uploaded.'}
                </Text>
                <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                  {(Object.keys(MODELS) as ModelKey[]).map((k) => (
                    <Chip key={k} label={`${MODELS[k].label} · ${MODELS[k].mb} MB`} active={modelChoice === k} onPress={() => setModelChoice(k)} />
                  ))}
                </View>
                <Text style={{ color: colors.muted, fontSize: 13 }}>{MODELS[modelChoice].note}</Text>
                <Button label="Download model" icon="download-outline" onPress={download} />
              </>
            )}
          </Card>
        ) : null}

        <Card style={{ paddingVertical: 22 }}>
          <ArabicWords words={words} statuses={showStatuses ? statuses : undefined} size={36} />
          <View style={{ marginTop: 12 }}>
            <Translation en={ayah.en} ha={ayah.ha} size={14} />
          </View>
        </Card>

        <View
          style={{
            borderRadius: radius.md,
            padding: 12,
            backgroundColor:
              phase === 'ayahDone' ? colors.correctBg : phase === 'correcting' || phase === 'repeat' ? colors.wrongBg : colors.goldTint,
          }}
        >
          <Text
            style={{
              textAlign: 'center',
              fontSize: 15,
              fontWeight: '600',
              color: phase === 'ayahDone' ? colors.correct : phase === 'correcting' || phase === 'repeat' ? colors.wrong : colors.text,
            }}
          >
            {message}
          </Text>
          {audioMissing && phase !== 'ayahDone' ? (
            <Pressable onPress={() => nav.navigate('Offline')} style={{ marginTop: 8, alignSelf: 'center' }}>
              <Text style={{ color: colors.primary, fontWeight: '800', textDecorationLine: 'underline' }}>
                Save audio for offline use
              </Text>
            </Pressable>
          ) : null}
          {mistakes > 0 && phase !== 'ayahDone' ? (
            <Text style={{ textAlign: 'center', color: colors.muted, fontSize: 12, marginTop: 4 }}>Corrections this ayah: {mistakes}</Text>
          ) : null}
        </View>

        {phase === 'ayahDone' ? (
          <Button label={ayahIdx + 1 >= surah.ayahs.length ? 'Finish' : 'Next ayah'} onPress={next} />
        ) : (
          <View style={{ alignItems: 'center', gap: 14 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 28 }}>
              <Pressable onPress={hearIt} disabled={listening || busy} style={{ alignItems: 'center', opacity: listening || busy ? 0.4 : 1 }}>
                <Ionicons name="volume-high" size={30} color={colors.primary} />
                <Text style={{ fontSize: 12, color: colors.muted }}>Hear it</Text>
              </Pressable>

              <Pressable
                onPress={listening ? stopMic : startMic}
                disabled={model !== 'ready' || busy}
                style={{
                  width: 88,
                  height: 88,
                  borderRadius: 44,
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: listening ? colors.wrong : colors.primary,
                  opacity: model !== 'ready' || busy ? 0.4 : 1,
                }}
              >
                <Ionicons name={listening ? 'stop' : 'mic'} size={40} color="#fff" />
              </Pressable>

              <Pressable onPress={skip} disabled={listening || busy} style={{ alignItems: 'center', opacity: listening || busy ? 0.4 : 1 }}>
                <Ionicons name="play-skip-forward" size={30} color={colors.primary} />
                <Text style={{ fontSize: 12, color: colors.muted }}>Skip</Text>
              </Pressable>
            </View>
            <Button label="Try demo (no microphone)" variant="outline" onPress={runDemo} disabled={listening || busy} style={{ minHeight: 42 }} />
          </View>
        )}

        {phase === 'idle' || phase === 'repeat' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <Text style={{ color: colors.muted }}>Go to ayah</Text>
            <TextInput
              value={jump}
              onChangeText={setJump}
              keyboardType="number-pad"
              placeholder={`1-${surah.ayahs.length}`}
              placeholderTextColor={colors.muted}
              style={{
                width: 90,
                borderWidth: 1.5,
                borderColor: colors.border,
                borderRadius: 10,
                paddingHorizontal: 10,
                paddingVertical: 6,
                textAlign: 'center',
                color: colors.text,
                backgroundColor: '#fff',
              }}
            />
            <Button label="Go" variant="outline" onPress={goTo} style={{ minHeight: 38, paddingHorizontal: 18 }} />
          </View>
        ) : null}

        <Text style={{ textAlign: 'center', color: colors.muted, fontSize: 12 }}>
          The checker compares the words you say. It cannot hear short-vowel (harakat) or tajweed errors, so keep
          practising with a teacher too.
        </Text>
      </ScrollView>
    </View>
  );
}
