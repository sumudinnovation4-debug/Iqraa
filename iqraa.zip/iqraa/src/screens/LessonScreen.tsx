import React, { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, radius } from '../theme';
import { findLesson, shuffle, Step } from '../data/lessons';
import { getAyah } from '../data/quranData';
// (getAyah is used for the fill / order steps)
import { displayWords } from '../lib/arabic';
import { playAyah, stopAudio } from '../lib/audio';
import { addMurajaah } from '../db/db';
import { useProgress } from '../store/progress';
import { ArabicWords, Button, ProgressBar, Translation, arabicStyle } from '../components/ui';
import { ScreenProps } from '../nav';
import { useSessionTimer } from '../hooks';

type Feedback = null | { correct: boolean; answer?: string };

export function LessonScreen({ route }: ScreenProps<'Lesson'>) {
  const nav = useNavigation();
  const insets = useSafeAreaInsets();
  useSessionTimer();
  const { addReward, completeLesson, translation } = useProgress();

  const lesson = useMemo(
    () => findLesson(route.params.id, translation === 'ha' ? 'ha' : 'en'),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [route.params.id],
  );
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [placed, setPlaced] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [right, setRight] = useState(0);
  const [asked, setAsked] = useState(0);
  const [finished, setFinished] = useState<null | { stars: number; xp: number }>(null);
  const [audioBusy, setAudioBusy] = useState(false);

  const step: Step | undefined = lesson?.steps[idx];

  // Word bank for "order" steps, shuffled once per step.
  const bank = useMemo(() => {
    if (!step || step.kind !== 'order') return [];
    return shuffle(displayWords(getAyah(step.ref.s, step.ref.a).ar).map((w, i) => ({ w, i })));
  }, [idx, step]);

  if (!lesson || !step) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Lesson not found.</Text>
      </View>
    );
  }

  const close = () => {
    stopAudio();
    nav.goBack();
  };

  const confirmClose = () =>
    Alert.alert('Leave lesson?', 'Your progress in this lesson will be lost.', [
      { text: 'Keep going', style: 'cancel' },
      { text: 'Leave', style: 'destructive', onPress: close },
    ]);

  const listen = async (s: number, a: number) => {
    setAudioBusy(true);
    try {
      await playAyah(s, a);
    } catch (e: any) {
      Alert.alert('Audio unavailable', e?.message ?? 'Could not load audio.');
    }
    setAudioBusy(false);
  };

  const advance = async () => {
    stopAudio();
    setPicked(null);
    setPlaced([]);
    setFeedback(null);
    if (idx + 1 < lesson.steps.length) {
      setIdx(idx + 1);
      return;
    }
    // Lesson complete.
    const acc = asked === 0 ? 1 : right / asked;
    const stars = acc >= 0.9 ? 3 : acc >= 0.7 ? 2 : 1;
    const xp = 20 + stars * 5;
    addReward(xp, 5);
    completeLesson(lesson.id, stars);
    if (lesson.memorizes) await addMurajaah(lesson.memorizes).catch(() => {});
    setFinished({ stars, xp });
  };

  const grade = (correct: boolean, answer?: string) => {
    setAsked((n) => n + 1);
    if (correct) {
      setRight((n) => n + 1);
      addReward(5);
    }
    setFeedback({ correct, answer });
  };

  const check = () => {
    if (step.kind === 'mcq') {
      grade(picked === step.answer, step.options[step.answer]);
    } else if (step.kind === 'fill') {
      const words = displayWords(getAyah(step.ref.s, step.ref.a).ar);
      grade(step.options[picked ?? -1] === words[step.hide], words[step.hide]);
    } else if (step.kind === 'order') {
      grade(
        placed.every((bankIdx, pos) => bank[bankIdx].i === pos),
        displayWords(getAyah(step.ref.s, step.ref.a).ar).join(' '),
      );
    }
  };

  const canCheck =
    (step.kind === 'mcq' || step.kind === 'fill') ? picked !== null : step.kind === 'order' ? placed.length === bank.length : false;

  // ---------- finished ----------
  if (finished) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.cream, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 }}>
        <Text style={{ fontSize: 30, fontWeight: '800', color: colors.primary }}>Lesson complete</Text>
        <View style={{ flexDirection: 'row' }}>
          {[1, 2, 3].map((n) => (
            <Ionicons key={n} name={n <= finished.stars ? 'star' : 'star-outline'} size={48} color={colors.gold} />
          ))}
        </View>
        <Text style={{ fontSize: 18, color: colors.text }}>
          {right}/{asked} correct · +{finished.xp} XP · +5 gems
        </Text>
        {lesson.memorizes ? (
          <Text style={{ color: colors.muted, textAlign: 'center' }}>
            This surah was added to Murajaah so you can review it with spaced repetition.
          </Text>
        ) : null}
        <Button label="Continue" onPress={close} style={{ alignSelf: 'stretch', marginTop: 12 }} />
      </View>
    );
  }

  // ---------- step bodies ----------
  let body: React.ReactNode = null;

  if (step.kind === 'teach') {
    body = (
      <View style={{ alignItems: 'center', gap: 14 }}>
        <Text style={{ fontSize: 22, fontWeight: '800', color: colors.primary, textAlign: 'center' }}>{step.title}</Text>
        {step.arabic ? <Text style={arabicStyle(step.arabic.length > 3 ? 32 : 80)}>{step.arabic}</Text> : null}
        {step.bodyHa === undefined || translation !== 'ha' ? (
          <Text style={{ fontSize: 17, color: colors.text, textAlign: 'center' }}>{step.body}</Text>
        ) : null}
        {step.bodyHa !== undefined && translation !== 'en' ? (
          <Text style={{ fontSize: 17, color: colors.primaryLight, textAlign: 'center', fontStyle: 'italic' }}>
            {step.bodyHa}
          </Text>
        ) : null}
        {step.audio ? (
          <Button
            label={audioBusy ? 'Playing...' : 'Listen'}
            icon="volume-high"
            variant="gold"
            disabled={audioBusy}
            onPress={() => listen(step.audio!.s, step.audio!.a)}
          />
        ) : null}
        {step.tajweed && step.tajweed.length > 0 ? (
          <View style={{ backgroundColor: colors.goldTint, borderRadius: radius.md, padding: 12, gap: 4, alignSelf: 'stretch' }}>
            <Text style={{ fontWeight: '800', color: colors.goldDark, fontSize: 12 }}>TAJWEED</Text>
            {step.tajweed.map((t, i) => (
              <Text key={i} style={{ fontSize: 14, color: colors.text }}>
                • {t}
              </Text>
            ))}
          </View>
        ) : null}
      </View>
    );
  } else if (step.kind === 'mcq') {
    body = (
      <View style={{ gap: 14 }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text, textAlign: 'center' }}>{step.prompt}</Text>
        {step.arabic ? <Text style={arabicStyle(step.arabic.length > 3 ? 30 : 72)}>{step.arabic}</Text> : null}
        {step.options.map((opt, i) => (
          <OptionButton
            key={i}
            label={opt}
            arabic={step.arabicOptions}
            state={optionState(i, picked, feedback, step.answer)}
            disabled={feedback !== null}
            onPress={() => setPicked(i)}
          />
        ))}
      </View>
    );
  } else if (step.kind === 'fill') {
    const words = displayWords(getAyah(step.ref.s, step.ref.a).ar);
    body = (
      <View style={{ gap: 14 }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text, textAlign: 'center' }}>Which word is missing?</Text>
        <ArabicWords words={words} hidden={new Set([step.hide])} size={32} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'center' }}>
          {step.options.map((opt, i) => (
            <OptionButton
              key={i}
              label={opt}
              arabic
              compact
              state={optionState(i, picked, feedback, step.options.indexOf(words[step.hide]))}
              disabled={feedback !== null}
              onPress={() => setPicked(i)}
            />
          ))}
        </View>
      </View>
    );
  } else {
    const ayah = getAyah(step.ref.s, step.ref.a);
    body = (
      <View style={{ gap: 14 }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text, textAlign: 'center' }}>Put the words in order</Text>
        <Translation en={ayah.en} ha={ayah.ha} />
        <View
          style={{
            minHeight: 90,
            borderRadius: radius.md,
            borderWidth: 2,
            borderStyle: 'dashed',
            borderColor: colors.border,
            padding: 10,
            flexDirection: 'row-reverse',
            flexWrap: 'wrap',
            gap: 8,
            justifyContent: 'center',
          }}
        >
          {placed.map((bankIdx, pos) => (
            <Pressable
              key={pos}
              disabled={feedback !== null}
              onPress={() => setPlaced(placed.filter((_, p) => p !== pos))}
              style={{ backgroundColor: colors.greenTint, borderRadius: 12, paddingHorizontal: 10 }}
            >
              <Text style={{ fontFamily: fonts.arabic, fontSize: 28, lineHeight: 52, color: colors.text }}>{bank[bankIdx].w}</Text>
            </Pressable>
          ))}
        </View>
        <View style={{ flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 8, justifyContent: 'center' }}>
          {bank.map((b, bankIdx) =>
            placed.includes(bankIdx) ? null : (
              <Pressable
                key={bankIdx}
                disabled={feedback !== null}
                onPress={() => setPlaced([...placed, bankIdx])}
                style={{ backgroundColor: colors.goldTint, borderRadius: 12, paddingHorizontal: 10 }}
              >
                <Text style={{ fontFamily: fonts.arabic, fontSize: 28, lineHeight: 52, color: colors.text }}>{b.w}</Text>
              </Pressable>
            ),
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: insets.top + 10, paddingBottom: 10 }}>
        <Pressable onPress={confirmClose} hitSlop={12}>
          <Ionicons name="close" size={28} color={colors.muted} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <ProgressBar pct={idx / lesson.steps.length} fill={colors.primary} track={colors.greenTint} height={12} />
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 30, flexGrow: 1, justifyContent: 'center' }}>{body}</ScrollView>

      <View
        style={{
          padding: 16,
          paddingBottom: insets.bottom + 16,
          backgroundColor: feedback ? (feedback.correct ? colors.correctBg : colors.wrongBg) : colors.cream,
          gap: 10,
        }}
      >
        {feedback ? (
          <View>
            <Text style={{ fontSize: 18, fontWeight: '800', color: feedback.correct ? colors.correct : colors.wrong }}>
              {feedback.correct ? 'Correct!' : 'Not quite'}
            </Text>
            {!feedback.correct && feedback.answer ? (
              <Text style={{ color: colors.text, marginTop: 2 }}>Answer: {feedback.answer}</Text>
            ) : null}
          </View>
        ) : null}
        {step.kind === 'teach' ? (
          <Button label="Continue" onPress={advance} />
        ) : feedback ? (
          <Button label="Continue" variant={feedback.correct ? 'primary' : 'danger'} onPress={advance} />
        ) : (
          <Button label="Check" disabled={!canCheck} onPress={check} />
        )}
      </View>
    </View>
  );
}

function optionState(i: number, picked: number | null, feedback: Feedback, answer: number): 'idle' | 'picked' | 'right' | 'wrong' {
  if (feedback) {
    if (i === answer) return 'right';
    if (i === picked) return 'wrong';
    return 'idle';
  }
  return i === picked ? 'picked' : 'idle';
}

function OptionButton({
  label,
  state,
  onPress,
  disabled,
  arabic,
  compact,
}: {
  label: string;
  state: 'idle' | 'picked' | 'right' | 'wrong';
  onPress: () => void;
  disabled?: boolean;
  arabic?: boolean;
  compact?: boolean;
}) {
  const border =
    state === 'right' ? colors.correct : state === 'wrong' ? colors.wrong : state === 'picked' ? colors.primary : colors.border;
  const bg = state === 'right' ? colors.correctBg : state === 'wrong' ? colors.wrongBg : state === 'picked' ? colors.greenTint : '#fff';
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={{
        borderWidth: 2,
        borderColor: border,
        backgroundColor: bg,
        borderRadius: radius.md,
        paddingVertical: arabic ? 2 : 14,
        paddingHorizontal: 16,
        alignItems: 'center',
        minWidth: compact ? 90 : undefined,
      }}
    >
      <Text
        style={
          arabic
            ? { fontFamily: fonts.arabic, fontSize: 30, lineHeight: 56, color: colors.text }
            : { fontSize: 16, color: colors.text, fontWeight: '600', textAlign: 'center' }
        }
      >
        {label}
      </Text>
    </Pressable>
  );
}
