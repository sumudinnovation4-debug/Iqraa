import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, FlatList, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts } from '../theme';
import { AyahRow, getAyahs, getBookmarkSet, getSurahRow, SurahRow, toggleBookmark } from '../db/db';
import { BISMILLAH, tajweedFor } from '../data/quranData';
import { useProgress } from '../store/progress';
import { cachedCount, downloadSurahAudio, playAyah, stopAudio } from '../lib/audio';
import { Button, Card, Chip, ScreenHeader } from '../components/ui';
import { ScreenProps } from '../nav';
import { useSessionTimer } from '../hooks';

export function ReaderScreen({ route }: ScreenProps<'Reader'>) {
  const { surah, ayah: focusAyah } = route.params;
  useSessionTimer();

  const [info, setInfo] = useState<SurahRow | null>(null);
  const [ayahs, setAyahs] = useState<AyahRow[]>([]);
  const [marks, setMarks] = useState<Set<number>>(new Set());
  const mode = useProgress((s) => s.translation);
  const changeMode = useProgress((s) => s.setTranslation);
  const [size, setSize] = useState(30);
  const [showTajweed, setShowTajweed] = useState(true);
  const [playing, setPlaying] = useState<number | null>(null);
  const [cached, setCached] = useState(0);
  const [dl, setDl] = useState<{ done: number; total: number } | null>(null);
  const playToken = useRef(0);
  const listRef = useRef<FlatList<AyahRow>>(null);

  useEffect(() => {
    getSurahRow(surah).then(setInfo);
    getAyahs(surah).then(setAyahs);
    getBookmarkSet(surah).then(setMarks);
    return () => {
      playToken.current++;
      stopAudio();
    };
  }, [surah]);

  // Count cached clips on open and after a download finishes (not on every progress tick:
  // that is one file check per ayah, which adds up on a 286-ayah surah).
  const downloading = dl !== null;
  useEffect(() => {
    if (info && !downloading) cachedCount(surah, info.ayah_count).then(setCached).catch(() => {});
  }, [info, surah, downloading]);

  useEffect(() => {
    if (focusAyah && ayahs.length) {
      const index = ayahs.findIndex((a) => a.n === focusAyah);
      if (index >= 0) setTimeout(() => listRef.current?.scrollToIndex({ index, animated: true }), 300);
    }
  }, [focusAyah, ayahs]);

  const playOne = useCallback(
    async (n: number) => {
      const token = ++playToken.current;
      setPlaying(n);
      try {
        await playAyah(surah, n);
      } catch (e: any) {
        Alert.alert('Audio unavailable', e?.message ?? 'Could not load audio.');
      }
      if (playToken.current === token) setPlaying(null);
    },
    [surah],
  );

  const playAll = useCallback(async () => {
    const token = ++playToken.current;
    for (const a of ayahs) {
      if (playToken.current !== token) return;
      setPlaying(a.n);
      try {
        await playAyah(surah, a.n);
      } catch (e: any) {
        Alert.alert('Audio unavailable', e?.message ?? 'Could not load audio.');
        break;
      }
    }
    if (playToken.current === token) setPlaying(null);
  }, [ayahs, surah]);

  const stop = () => {
    playToken.current++;
    stopAudio();
    setPlaying(null);
  };

  const download = async () => {
    if (!info) return;
    setDl({ done: 0, total: info.ayah_count });
    try {
      await downloadSurahAudio(surah, info.ayah_count, (done, total) => setDl({ done, total }));
    } catch (e: any) {
      Alert.alert('Download failed', e?.message ?? 'Check your connection and try again.');
    }
    setDl(null);
  };

  const bookmark = async (n: number) => {
    const on = await toggleBookmark(surah, n);
    setMarks((prev) => {
      const next = new Set(prev);
      on ? next.add(n) : next.delete(n);
      return next;
    });
  };

  const total = info?.ayah_count ?? 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader
        title={info?.en ?? 'Reading'}
        subtitle={info ? `${info.meaning} · ${info.ayah_count} ayahs · Juz ${info.juz}` : undefined}
        right={
          <Text style={{ fontFamily: fonts.arabicBold, fontSize: 26, color: colors.primary, marginRight: 6 }}>
            {info?.ar}
          </Text>
        }
      />
      <View style={{ paddingHorizontal: 16, gap: 10, paddingBottom: 8 }}>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <Chip label="EN + HA" active={mode === 'both'} onPress={() => changeMode('both')} />
          <Chip label="English" active={mode === 'en'} onPress={() => changeMode('en')} />
          <Chip label="Hausa" active={mode === 'ha'} onPress={() => changeMode('ha')} />
          <Chip label="Tajweed" active={showTajweed} onPress={() => setShowTajweed((v) => !v)} />
          <Pressable onPress={() => setSize((s) => Math.max(22, s - 4))} hitSlop={8}>
            <Ionicons name="remove-circle-outline" size={28} color={colors.primary} />
          </Pressable>
          <Pressable onPress={() => setSize((s) => Math.min(48, s + 4))} hitSlop={8}>
            <Ionicons name="add-circle-outline" size={28} color={colors.primary} />
          </Pressable>
        </View>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {playing === null ? (
            <Button label="Play all" icon="play" onPress={playAll} style={{ flex: 1, minHeight: 44 }} />
          ) : (
            <Button label="Stop" icon="stop" variant="gold" onPress={stop} style={{ flex: 1, minHeight: 44 }} />
          )}
          <Button
            label={
              dl ? `Saving ${dl.done}/${dl.total}` : cached >= total && total > 0 ? 'Audio saved' : 'Save audio offline'
            }
            icon={cached >= total && total > 0 ? 'checkmark-circle' : 'download-outline'}
            variant="outline"
            disabled={Boolean(dl) || (cached >= total && total > 0)}
            onPress={download}
            style={{ flex: 1.4, minHeight: 44 }}
          />
        </View>
      </View>

      <FlatList
        ref={listRef}
        data={ayahs}
        keyExtractor={(a) => String(a.n)}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        initialNumToRender={8}
        windowSize={7}
        onScrollToIndexFailed={(info) => {
          // Rows are variable height: jump near the target, then retry once it is rendered.
          listRef.current?.scrollToOffset({ offset: info.averageItemLength * info.index, animated: false });
          setTimeout(() => listRef.current?.scrollToIndex({ index: info.index, animated: true }), 150);
        }}
        ListHeaderComponent={
          surah !== 1 && surah !== 9 ? (
            <Text
              style={{
                fontFamily: fonts.arabic,
                fontSize: 30,
                lineHeight: 56,
                color: colors.primary,
                textAlign: 'center',
                writingDirection: 'rtl',
                marginBottom: 4,
              }}
            >
              {BISMILLAH}
            </Text>
          ) : null
        }
        renderItem={({ item }) => {
          const notes = showTajweed ? tajweedFor(surah, item.n) : [];
          const active = playing === item.n;
          return (
            <Card style={active ? { borderColor: colors.gold, borderWidth: 2 } : undefined}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                <View
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 15,
                    backgroundColor: colors.goldTint,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text style={{ fontWeight: '800', color: colors.primary }}>{item.n}</Text>
                </View>
                <View style={{ flex: 1 }} />
                <Pressable onPress={() => (active ? stop() : playOne(item.n))} hitSlop={10} style={{ marginRight: 16 }}>
                  <Ionicons name={active ? 'stop-circle' : 'play-circle'} size={30} color={colors.primary} />
                </Pressable>
                <Pressable onPress={() => bookmark(item.n)} hitSlop={10}>
                  <Ionicons
                    name={marks.has(item.n) ? 'bookmark' : 'bookmark-outline'}
                    size={26}
                    color={marks.has(item.n) ? colors.gold : colors.muted}
                  />
                </Pressable>
              </View>
              <Text
                style={{
                  fontFamily: fonts.arabic,
                  fontSize: size,
                  lineHeight: size * 1.9,
                  color: colors.text,
                  textAlign: 'right',
                  writingDirection: 'rtl',
                }}
              >
                {item.ar}
              </Text>
              {mode !== 'ha' ? <Text style={{ fontSize: 15, color: colors.text, marginTop: 8 }}>{item.en}</Text> : null}
              {mode !== 'en' ? (
                <Text style={{ fontSize: 15, color: colors.primaryLight, marginTop: 6, fontStyle: 'italic' }}>{item.ha}</Text>
              ) : null}
              {notes.length > 0 ? (
                <View
                  style={{
                    marginTop: 10,
                    padding: 10,
                    borderRadius: 12,
                    backgroundColor: colors.goldTint,
                    gap: 4,
                  }}
                >
                  <Text style={{ fontWeight: '800', color: colors.goldDark, fontSize: 12 }}>TAJWEED</Text>
                  {notes.map((t, i) => (
                    <Text key={i} style={{ fontSize: 13, color: colors.text }}>
                      • {t}
                    </Text>
                  ))}
                </View>
              ) : null}
            </Card>
          );
        }}
      />
    </View>
  );
}
