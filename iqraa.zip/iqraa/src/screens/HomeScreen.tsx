import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, radius, shadow } from '../theme';
import { useProgress, levelFromXp } from '../store/progress';
import { PatternBackground } from '../components/Pattern';
import { TopBar } from '../components/TopBar';
import { ModeCard } from '../components/ModeCard';
import { ProgressBar } from '../components/ui';

export function HomeScreen() {
  const nav = useNavigation<any>();
  const { name, xp, goalMinutes, todaySeconds } = useProgress();
  const { level } = levelFromXp(xp);
  const minutes = Math.floor(todaySeconds / 60);
  const pct = Math.min(1, minutes / goalMinutes);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <PatternBackground />
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
        <LinearGradient colors={['#F4E7B8', '#CFE3B6']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
          <Text style={styles.greeting}>Assalamu Alaikum, {name}</Text>
          <Text style={styles.goal}>
            Level {level} • Goal: {goalMinutes} min today
          </Text>
          <View style={styles.progressRow}>
            <Text style={styles.progressLabel}>Daily Progress</Text>
            <Text style={styles.progressValue}>
              {minutes}/{goalMinutes} min
            </Text>
            <Text style={styles.progressValue}>{Math.round(pct * 100)}%</Text>
          </View>
          <ProgressBar pct={pct} fill={colors.gold} track="#8FB27A" height={10} />
        </LinearGradient>

        <Text style={styles.section}>Choose Your Mode</Text>

        <View style={styles.row}>
          <ModeCard
            tint="gold"
            icon={<Ionicons name="book-outline" size={56} color={colors.primary} />}
            title="Read Mode"
            subtitle="Read with Tajweed"
            cta="Start"
            onPress={() => nav.navigate('ReadList')}
          />
          <ModeCard
            tint="green"
            icon={<MaterialCommunityIcons name="lightbulb-on" size={54} color={colors.gold} />}
            title="Learn Mode"
            subtitle="Learn New Verses"
            cta="Start"
            onPress={() => nav.navigate('LearnPath')}
          />
        </View>
        <View style={styles.row}>
          <ModeCard
            tint="gold"
            icon={<MaterialCommunityIcons name="microphone" size={56} color={colors.goldDark} />}
            title="Recite Mode"
            note="(The Corrector)"
            subtitle="Pronunciation Checker"
            cta="Practice"
            onPress={() => nav.navigate('ReciteSelect')}
          />
          <ModeCard
            tint="green"
            icon={<MaterialCommunityIcons name="sync" size={56} color={colors.goldDark} />}
            title="Murajaah Mode"
            subtitle="Review Memorization"
            cta="Review"
            onPress={() => nav.navigate('MurajaahHome')}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: { borderRadius: radius.lg, padding: 18, ...shadow },
  greeting: { fontSize: 25, fontWeight: '800', color: colors.primaryDark, textAlign: 'center' },
  goal: { fontSize: 16, color: colors.text, textAlign: 'center', marginTop: 8 },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 14, marginBottom: 8 },
  progressLabel: { fontSize: 15, color: colors.goldDark, fontWeight: '600' },
  progressValue: { fontSize: 15, color: colors.text, fontWeight: '700' },
  section: { fontSize: 26, fontWeight: '800', color: colors.primary, textAlign: 'center', marginVertical: 18 },
  row: { flexDirection: 'row', gap: 14, marginBottom: 14 },
});
