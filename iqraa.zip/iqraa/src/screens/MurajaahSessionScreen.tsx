import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { getSurah } from '../data/quranData';
import { displayWords } from '../lib/arabic';
import { MurajaahRow, listMurajaah, saveSchedule } from '../db/db';
import { RATING_LABELS, Rating, nextSchedule } from '../lib/srs';
import { playAyah, stopAudio } from '../lib/audio';
import { useProgress } from '../store/progress';
import { ArabicWords, Button, Card, ProgressBar, ScreenHeader, Translation } from '../components/ui';
import { ScreenProps } from '../nav';
import { useSessionTimer } from '../hooks';

function previewInterval(row: MurajaahRow, rating: Rating): string {
  const s = nextSchedule({ ease: row.ease, intervalDays: row.interval_days, reps: row.reps }, rating);
  return rating === 0 ? '10 min' : `${s.intervalDays} d`;
}

export function MurajaahSessionScreen({ route }: ScreenProps<'MurajaahSession'>) {
  const nav = useNavigation();
  const addReward = useProgress((s) => s.addReward);
  useSessionTimer();

  const surah = useMemo(() => getSurah(route.params.surah), [route.params.surah]);
  const [row, setRow] = useState<MurajaahRow | null>(null);
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [rating, setRating] = useState(false);

  useEffect(() => {
    listMurajaah().then((rows) => setRow(rows.find((r) => r.surah === surah.id) ?? null));
    return () => stopAudio();
  }, [surah.id]);

  const ayah = surah.ayahs[idx];
  const words = useMemo(() => displayWords(ayah.ar), [ayah]);
  // Everything except the first word is hidden until tapped: a recall prompt.
  const hidden = useMemo(() => {
    const h = new Set<number>();
    words.forEach((_, i) => {
      if (i > 0 && !revealed.has(i)) h.add(i);
    });
    return h;
  }, [words, revealed]);

  const allShown = hidden.size === 0;

  const toggle = (i: number) => setRevealed((prev) => new Set(prev).add(i));
  const revealAll = () => setRevealed(new Set(words.map((_, i) => i)));

  const next = () => {
    stopAudio();
    setRevealed(new Set());
    if (idx + 1 >= surah.ayahs.length) setRating(true);
    else setIdx(idx + 1);
  };

  const rate = async (r: Rating) => {
    if (row) {
      await saveSchedule(
        surah.id,
        nextSchedule({ ease: row.ease, intervalDays: row.interval_days, reps: row.reps }, r),
      );
    }
    addReward(10, 2);
    nav.goBack();
  };

  if (rating) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.cream }}>
        <ScreenHeader title={surah.en} subtitle="How did that go?" />
        <View style={{ padding: 20, gap: 12 }}>
          <Text style={{ color: colors.text, fontSize: 16, textAlign: 'center', marginBottom: 6 }}>
            Rate your recall of the whole surah. This sets when it comes back for review.
          </Text>
          {([0, 1, 2, 3] as Rating[]).map((r) => (
            <Button
              key={r}
              label={`${RATING_LABELS[r]}${row ? ` · next in ${previewInterval(row, r)}` : ''}`}
              variant={r === 0 ? 'danger' : r === 3 ? 'gold' : r === 2 ? 'primary' : 'outline'}
              onPress={() => rate(r)}
            />
          ))}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title={surah.en} subtitle={`Recall ayah ${ayah.n} of ${surah.ayahs.length}`} />
      <View style={{ paddingHorizontal: 16 }}>
        <ProgressBar pct={idx / surah.ayahs.length} fill={colors.primary} />
      </View>
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        <Card style={{ gap: 14, paddingVertical: 22 }}>
          <Translation en={ayah.en} ha={ayah.ha} />
          <ArabicWords words={words} hidden={hidden} onWordPress={toggle} size={36} />
          <Text style={{ textAlign: 'center', color: colors.muted, fontSize: 12 }}>
            Say it from memory. Tap a hidden word if you need a hint.
          </Text>
        </Card>

        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button label="Hear it" icon="volume-high" variant="outline" onPress={() => playAyah(surah.id, ayah.n).catch(() => {})} style={{ flex: 1, minHeight: 46 }} />
          <Button label="Reveal all" icon="eye" variant="gold" onPress={revealAll} disabled={allShown} style={{ flex: 1, minHeight: 46 }} />
        </View>
        <Button label={idx + 1 >= surah.ayahs.length ? 'Finish and rate' : 'Next ayah'} onPress={next} />
        {idx + 1 < surah.ayahs.length ? (
          <Button
            label="Finish early and rate"
            variant="outline"
            onPress={() => {
              stopAudio();
              setRating(true);
            }}
            style={{ minHeight: 42 }}
          />
        ) : null}
      </ScrollView>
    </View>
  );
}
