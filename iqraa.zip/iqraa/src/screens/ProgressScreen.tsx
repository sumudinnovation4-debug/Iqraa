import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme';
import { useProgress, levelFromXp } from '../store/progress';
import { getActivity, listMurajaah } from '../db/db';
import { lastNDays, shortWeekday } from '../lib/dates';
import { buildUnits } from '../data/lessons';
import { getSurah } from '../data/quranData';
import { TopBar } from '../components/TopBar';
import { Card, ProgressBar } from '../components/ui';

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <Card style={{ flex: 1, alignItems: 'center', paddingVertical: 14 }}>
      <Text style={{ fontSize: 26, fontWeight: '800', color: colors.primary }}>{value}</Text>
      <Text style={{ fontSize: 13, color: colors.muted, marginTop: 2 }}>{label}</Text>
    </Card>
  );
}

export function ProgressScreen() {
  const { xp, streak, gems, completed, goalMinutes } = useProgress();
  const { level, into, needed, pct } = levelFromXp(xp);
  const [week, setWeek] = useState<{ day: string; seconds: number }[]>([]);
  const [memorized, setMemorized] = useState<number[]>([]);

  useFocusEffect(
    useCallback(() => {
      getActivity(lastNDays(7)).then(setWeek).catch(() => {});
      listMurajaah().then((r) => setMemorized(r.map((x) => x.surah))).catch(() => {});
    }, []),
  );

  const totalLessons = buildUnits().reduce((n, u) => n + u.lessons.length, 0);
  const maxMin = Math.max(goalMinutes, ...week.map((d) => d.seconds / 60), 1);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text }}>Level {level}</Text>
          <Text style={{ color: colors.muted, marginBottom: 10 }}>
            {into}/{needed} XP to level {level + 1}
          </Text>
          <ProgressBar pct={pct} />
        </Card>

        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Stat label="Total XP" value={xp} />
          <Stat label="Day streak" value={streak} />
          <Stat label="Gems" value={gems} />
        </View>

        <Card>
          <Text style={{ fontSize: 16, fontWeight: '800', color: colors.text, marginBottom: 12 }}>
            Minutes this week (goal {goalMinutes})
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, gap: 8 }}>
            {week.map((d) => {
              const m = d.seconds / 60;
              return (
                <View key={d.day} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', height: '100%' }}>
                  <Text style={{ fontSize: 11, color: colors.muted }}>{Math.round(m)}</Text>
                  <View
                    style={{
                      width: '70%',
                      height: Math.max(4, (m / maxMin) * 84),
                      borderRadius: 6,
                      backgroundColor: m >= goalMinutes ? colors.primary : colors.gold,
                    }}
                  />
                  <Text style={{ fontSize: 11, color: colors.muted, marginTop: 4 }}>{shortWeekday(d.day)}</Text>
                </View>
              );
            })}
          </View>
        </Card>

        <Card>
          <Text style={{ fontSize: 16, fontWeight: '800', color: colors.text }}>Lessons</Text>
          <Text style={{ color: colors.muted, marginTop: 4, marginBottom: 10 }}>
            {Object.keys(completed).length} of {totalLessons} completed
          </Text>
          <ProgressBar pct={Object.keys(completed).length / totalLessons} fill={colors.primary} />
        </Card>

        <Card>
          <Text style={{ fontSize: 16, fontWeight: '800', color: colors.text, marginBottom: 6 }}>Memorized surahs</Text>
          {memorized.length === 0 ? (
            <Text style={{ color: colors.muted }}>Finish a surah's lessons to add it to Murajaah.</Text>
          ) : (
            memorized.map((id) => (
              <Text key={id} style={{ fontSize: 16, color: colors.text, paddingVertical: 3 }}>
                • {getSurah(id).en}
              </Text>
            ))
          )}
        </Card>
      </ScrollView>
    </View>
  );
}
