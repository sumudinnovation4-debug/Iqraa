import React, { useMemo } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow } from '../theme';
import { buildUnits } from '../data/lessons';
import { useProgress } from '../store/progress';
import { ScreenHeader } from '../components/ui';
import { useSessionTimer } from '../hooks';

export function LearnPathScreen() {
  const nav = useNavigation<any>();
  const completed = useProgress((s) => s.completed);
  useSessionTimer();
  const units = useMemo(() => buildUnits(), []);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title="Learn Mode" subtitle="Noorani Qaida to Juz Amma" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        {units.map((unit, ui) => (
          <View key={unit.id} style={{ marginBottom: 26 }}>
            <View
              style={{
                backgroundColor: ui % 2 === 0 ? colors.primary : colors.gold,
                borderRadius: radius.md,
                paddingVertical: 12,
                paddingHorizontal: 16,
                marginBottom: 16,
              }}
            >
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 18 }}>
                Unit {ui + 1} · {unit.title}
              </Text>
            </View>
            {unit.lessons.map((lesson, li) => {
              const stars = completed[lesson.id] ?? 0;
              const done = stars > 0;
              const unlocked = li === 0 || (completed[unit.lessons[li - 1].id] ?? 0) > 0;
              const offset = [0, 46, 0, -46][li % 4];
              return (
                <View key={lesson.id} style={{ alignItems: 'center', marginBottom: 18, transform: [{ translateX: offset }] }}>
                  <Pressable
                    disabled={!unlocked}
                    onPress={() => nav.navigate('Lesson', { id: lesson.id })}
                    style={({ pressed }) => ({
                      width: 84,
                      height: 84,
                      borderRadius: 42,
                      backgroundColor: !unlocked ? '#CFCFC4' : done ? colors.gold : colors.primary,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderBottomWidth: 6,
                      borderBottomColor: !unlocked ? '#B3B3A7' : done ? colors.goldDark : colors.primaryDark,
                      opacity: pressed ? 0.9 : 1,
                      ...shadow,
                    })}
                  >
                    <Ionicons
                      name={!unlocked ? 'lock-closed' : done ? 'checkmark' : 'play'}
                      size={36}
                      color="#fff"
                    />
                  </Pressable>
                  <Text style={{ marginTop: 8, fontWeight: '800', color: colors.text, fontSize: 16 }}>{lesson.title}</Text>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>{lesson.subtitle}</Text>
                  {done ? (
                    <View style={{ flexDirection: 'row', marginTop: 4 }}>
                      {[1, 2, 3].map((n) => (
                        <Ionicons key={n} name={n <= stars ? 'star' : 'star-outline'} size={16} color={colors.gold} />
                      ))}
                    </View>
                  ) : null}
                </View>
              );
            })}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
