import React from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { useProgress } from '../store/progress';
import { TopBar } from '../components/TopBar';
import { Button, Card, Chip } from '../components/ui';

export function ProfileScreen() {
  const nav = useNavigation<any>();
  const { name, setName, goalMinutes, setGoal, translation, setTranslation, reset } = useProgress();

  const confirmReset = () =>
    Alert.alert('Reset all progress?', 'XP, streak, lessons, bookmarks and Murajaah schedule will be erased.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reset', style: 'destructive', onPress: () => reset() },
    ]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 8 }}>Your name</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            style={{
              borderWidth: 1.5,
              borderColor: colors.border,
              borderRadius: 12,
              paddingHorizontal: 14,
              paddingVertical: 10,
              fontSize: 17,
              color: colors.text,
            }}
          />
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 4 }}>Translation</Text>
          <Text style={{ color: colors.muted, marginBottom: 10 }}>Used in Read, Learn, Recite and Murajaah.</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Chip label="Hausa + English" active={translation === 'both'} onPress={() => setTranslation('both')} />
            <Chip label="Hausa" active={translation === 'ha'} onPress={() => setTranslation('ha')} />
            <Chip label="English" active={translation === 'en'} onPress={() => setTranslation('en')} />
          </View>
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 10 }}>Daily goal</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            {[5, 10, 15, 20, 30].map((m) => (
              <Chip key={m} label={`${m} min`} active={goalMinutes === m} onPress={() => setGoal(m)} />
            ))}
          </View>
        </Card>

        <Card style={{ gap: 8 }}>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text }}>Offline downloads</Text>
          <Text style={{ color: colors.muted }}>
            The Quran text and translations are always on your phone. To use Recite and audio with no internet, save the
            speech model and the recitation audio here once.
          </Text>
          <Button label="Manage offline downloads" icon="cloud-download-outline" onPress={() => nav.navigate('Offline')} />
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 6 }}>About the content</Text>
          <Text style={{ color: colors.muted, lineHeight: 20 }}>
            Arabic: Uthmani text from Tanzil.net. English: Sahih International. Hausa: Abubakar Mahmoud Gumi. Audio:
            Mishary Alafasy via EveryAyah.com. Tajweed notes are a short curated set for Al-Fatiha and Al-Ikhlas.
          </Text>
        </Card>

        <Button label="Reset progress" variant="danger" onPress={confirmReset} />
      </ScrollView>
    </View>
  );
}
