import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme';
import { useProgress } from '../store/progress';
import { MODELS, ModelKey, installedModels, removeModel } from '../lib/whisper';
import { TopBar } from '../components/TopBar';
import { Button, Card, Chip } from '../components/ui';

export function ProfileScreen() {
  const { name, setName, goalMinutes, setGoal, translation, setTranslation, reset } = useProgress();
  const [installed, setInstalled] = useState<ModelKey[]>([]);

  const refresh = useCallback(() => {
    installedModels().then(setInstalled).catch(() => {});
  }, []);
  useFocusEffect(refresh);

  const confirmReset = () =>
    Alert.alert('Reset all progress?', 'XP, streak, lessons, bookmarks and Murajaah schedule will be erased.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reset', style: 'destructive', onPress: () => reset() },
    ]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 8 }}>Your name</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            style={{
              borderWidth: 1.5,
              borderColor: colors.border,
              borderRadius: 12,
              paddingHorizontal: 14,
              paddingVertical: 10,
              fontSize: 17,
              color: colors.text,
            }}
          />
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 4 }}>Translation</Text>
          <Text style={{ color: colors.muted, marginBottom: 10 }}>
            Used in Read, Learn, Recite and Murajaah.
          </Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Chip label="Hausa + English" active={translation === 'both'} onPress={() => setTranslation('both')} />
            <Chip label="Hausa" active={translation === 'ha'} onPress={() => setTranslation('ha')} />
            <Chip label="English" active={translation === 'en'} onPress={() => setTranslation('en')} />
          </View>
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 10 }}>Daily goal</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            {[5, 10, 15, 20, 30].map((m) => (
              <Chip key={m} label={`${m} min`} active={goalMinutes === m} onPress={() => setGoal(m)} />
            ))}
          </View>
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 6 }}>
            Offline recitation model
          </Text>
          <Text style={{ color: colors.muted, marginBottom: 10 }}>
            Recite Mode listens on your device. The model downloads once, then works offline.
          </Text>
          {(Object.keys(MODELS) as ModelKey[]).map((k) => (
            <View key={k} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.text, fontWeight: '700' }}>
                  {MODELS[k].label} · {MODELS[k].mb} MB
                </Text>
                <Text style={{ color: colors.muted, fontSize: 13 }}>
                  {installed.includes(k) ? 'Installed' : 'Not downloaded'}
                </Text>
              </View>
              {installed.includes(k) ? (
                <Button
                  label="Remove"
                  variant="outline"
                  onPress={async () => {
                    await removeModel(k);
                    refresh();
                  }}
                  style={{ minHeight: 40, paddingHorizontal: 16 }}
                />
              ) : null}
            </View>
          ))}
          <Text style={{ color: colors.muted, fontSize: 13, marginTop: 6 }}>
            Download from the Recite screen the first time you practise.
          </Text>
        </Card>

        <Card>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text, marginBottom: 6 }}>About the content</Text>
          <Text style={{ color: colors.muted, lineHeight: 20 }}>
            Arabic: Uthmani text from Tanzil.net. English: Sahih International. Hausa: Abubakar Mahmoud Gumi. Audio:
            Mishary Alafasy via EveryAyah.com. Tajweed notes are a short curated set for the bundled surahs.
          </Text>
        </Card>

        <Button label="Reset progress" variant="danger" onPress={confirmReset} />
      </ScrollView>
    </View>
  );
}
