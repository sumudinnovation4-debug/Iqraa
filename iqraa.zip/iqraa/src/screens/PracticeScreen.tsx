import React, { useCallback, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { countDueMurajaah } from '../db/db';
import { TopBar } from '../components/TopBar';
import { ModeCard } from '../components/ModeCard';
import { Card } from '../components/ui';

export function PracticeScreen() {
  const nav = useNavigation<any>();
  const [due, setDue] = useState(0);
  useFocusEffect(
    useCallback(() => {
      countDueMurajaah().then(setDue).catch(() => {});
    }, []),
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.primary, textAlign: 'center' }}>Practice</Text>
        <Card>
          <Text style={{ fontSize: 16, color: colors.text, textAlign: 'center' }}>
            {due > 0
              ? `${due} surah${due > 1 ? 's' : ''} due for review today.`
              : 'Nothing due for review. Recite a surah to keep it fresh.'}
          </Text>
        </Card>
        <View style={{ flexDirection: 'row', gap: 14 }}>
          <ModeCard
            tint="gold"
            icon={<MaterialCommunityIcons name="microphone" size={56} color={colors.goldDark} />}
            title="Recite"
            note="(The Corrector)"
            subtitle="Pronunciation Checker"
            cta="Practice"
            onPress={() => nav.navigate('ReciteSelect')}
          />
          <ModeCard
            tint="green"
            icon={<MaterialCommunityIcons name="sync" size={56} color={colors.goldDark} />}
            title="Murajaah"
            subtitle={due > 0 ? `${due} due now` : 'Review Memorization'}
            cta="Review"
            onPress={() => nav.navigate('MurajaahHome')}
          />
        </View>
        <Pressable onPress={() => nav.navigate('Offline')}>
          <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <MaterialCommunityIcons name="cloud-download-outline" size={30} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '800', color: colors.text }}>Offline downloads</Text>
              <Text style={{ color: colors.muted, fontSize: 13 }}>Save the speech model and audio to practise with no internet</Text>
            </View>
          </Card>
        </Pressable>
      </ScrollView>
    </View>
  );
}
