import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme';
import { QURAN } from '../data/quranData';
import { DownloadJob, MB_PER_AYAH, downloadAyahs, keyOf, listCachedKeys } from '../lib/audio';
import { MODELS, ModelKey, downloadModel, installedModels, removeModel } from '../lib/whisper';
import { Button, Card, ProgressBar, ScreenHeader } from '../components/ui';

const JUZ_AMMA_IDS = [1, ...Array.from({ length: 37 }, (_, k) => 78 + k)];

const itemsFor = (ids: number[]) =>
  QURAN.filter((s) => ids.includes(s.id)).flatMap((s) => s.ayahs.map((a) => ({ s: s.id, a: a.n })));

export function OfflineScreen() {
  const [cached, setCached] = useState<Set<string>>(new Set());
  const [models, setModels] = useState<ModelKey[]>([]);
  const [modelDl, setModelDl] = useState<{ key: ModelKey; p: number } | null>(null);
  const [job, setJob] = useState<{ label: string; done: number; total: number } | null>(null);
  const [note, setNote] = useState('');
  const [query, setQuery] = useState('');
  const jobRef = useRef<DownloadJob | null>(null);

  const refresh = useCallback(() => {
    listCachedKeys().then(setCached).catch(() => {});
    installedModels().then(setModels).catch(() => {});
  }, []);
  useFocusEffect(refresh);

  // Stop any running download when leaving the screen.
  useEffect(
    () => () => {
      if (jobRef.current) jobRef.current.cancelled = true;
    },
    [],
  );

  const packs = useMemo(
    () => [
      { label: 'Al-Fatiha + Juz Amma', note: 'Recommended: all the surahs in Learn mode', items: itemsFor(JUZ_AMMA_IDS) },
      { label: 'Whole Quran', note: 'Every ayah. Large: use Wi-Fi', items: itemsFor(QURAN.map((s) => s.id)) },
    ],
    [],
  );

  const run = async (label: string, items: { s: number; a: number }[]) => {
    if (job) return;
    const todo = items.filter((i) => !cached.has(keyOf(i.s, i.a)));
    if (todo.length === 0) {
      setNote(`${label}: everything is already saved.`);
      return;
    }
    const j: DownloadJob = { cancelled: false };
    jobRef.current = j;
    setNote('');
    setJob({ label, done: 0, total: todo.length });
    const res = await downloadAyahs(todo, j, (done, total) => setJob({ label, done, total }));
    jobRef.current = null;
    setJob(null);
    refresh();
    if (res.cancelled) setNote(`Stopped. ${res.saved} ayahs saved. Run it again any time to continue.`);
    else if (res.aborted)
      setNote(`No connection. ${res.saved} ayahs saved so far. Reconnect and run it again to continue.`);
    else if (res.failed > 0) setNote(`${res.saved} saved, ${res.failed} failed. Run it again to retry those.`);
    else setNote(`${label}: saved ${res.saved} ayahs. They now play offline.`);
  };

  const downloadSpeech = async (key: ModelKey) => {
    setModelDl({ key, p: 0 });
    try {
      await downloadModel(key, (p) => setModelDl({ key, p }));
    } catch (e: any) {
      Alert.alert('Download failed', e?.message ?? 'Check your connection and try again.');
    }
    setModelDl(null);
    refresh();
  };

  const q = query.trim().toLowerCase();
  const matches = q
    ? QURAN.filter(
        (s) => String(s.id) === q || s.en.toLowerCase().includes(q) || s.meaning.toLowerCase().includes(q) || s.ar.includes(q),
      ).slice(0, 8)
    : [];

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title="Offline downloads" subtitle="Save what you need, then use Iqraa with no internet" />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14, paddingBottom: 40 }}>
        <Card style={{ gap: 8 }}>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text }}>Speech model (for Recite)</Text>
          <Text style={{ color: colors.muted }}>
            Needed once. After it is saved, Recite listens fully offline and nothing is uploaded.
          </Text>
          {(Object.keys(MODELS) as ModelKey[]).map((k) => {
            const have = models.includes(k);
            const busy = modelDl?.key === k;
            return (
              <View key={k} style={{ gap: 6, paddingVertical: 4 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.text, fontWeight: '700' }}>
                      {MODELS[k].label} · {MODELS[k].mb} MB
                    </Text>
                    <Text style={{ color: have ? colors.correct : colors.muted, fontSize: 13 }}>
                      {have ? 'Saved on this phone' : MODELS[k].note}
                    </Text>
                  </View>
                  {have ? (
                    <Button
                      label="Remove"
                      variant="outline"
                      onPress={async () => {
                        await removeModel(k);
                        refresh();
                      }}
                      style={{ minHeight: 40, paddingHorizontal: 16 }}
                    />
                  ) : (
                    <Button
                      label={busy ? `${Math.round((modelDl?.p ?? 0) * 100)}%` : 'Download'}
                      disabled={modelDl !== null}
                      onPress={() => downloadSpeech(k)}
                      style={{ minHeight: 40, paddingHorizontal: 16 }}
                    />
                  )}
                </View>
                {busy ? <ProgressBar pct={modelDl?.p ?? 0} /> : null}
              </View>
            );
          })}
        </Card>

        <Card style={{ gap: 10 }}>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text }}>Audio (Read, Learn, Recite, Murajaah)</Text>
          <Text style={{ color: colors.muted }}>
            Recite plays the correct recitation after a mistake, so every ayah you practise needs its audio saved.
          </Text>

          {packs.map((p) => {
            const saved = p.items.filter((i) => cached.has(keyOf(i.s, i.a))).length;
            const missing = p.items.length - saved;
            return (
              <View key={p.label} style={{ gap: 6, paddingTop: 6 }}>
                <Text style={{ color: colors.text, fontWeight: '700' }}>{p.label}</Text>
                <Text style={{ color: colors.muted, fontSize: 13 }}>
                  {p.note} · {saved}/{p.items.length} saved
                  {missing > 0 ? ` · about ${Math.max(1, Math.round(missing * MB_PER_AYAH))} MB to download` : ''}
                </Text>
                <ProgressBar pct={p.items.length ? saved / p.items.length : 0} fill={colors.primary} />
                <Button
                  label={missing === 0 ? 'All saved' : saved > 0 ? 'Continue download' : 'Download'}
                  icon={missing === 0 ? 'checkmark-circle' : 'download-outline'}
                  variant={missing === 0 ? 'outline' : 'primary'}
                  disabled={job !== null || missing === 0}
                  onPress={() => run(p.label, p.items)}
                  style={{ minHeight: 44 }}
                />
              </View>
            );
          })}

          {job ? (
            <View style={{ gap: 8, backgroundColor: colors.goldTint, borderRadius: 14, padding: 12 }}>
              <Text style={{ color: colors.text, fontWeight: '700' }}>
                Saving {job.label}: {job.done}/{job.total}
              </Text>
              <ProgressBar pct={job.total ? job.done / job.total : 0} />
              <Button
                label="Stop"
                variant="outline"
                onPress={() => {
                  if (jobRef.current) jobRef.current.cancelled = true;
                }}
                style={{ minHeight: 40 }}
              />
            </View>
          ) : null}
          {note ? <Text style={{ color: colors.text, fontWeight: '600' }}>{note}</Text> : null}
        </Card>

        <Card style={{ gap: 8 }}>
          <Text style={{ fontWeight: '800', fontSize: 16, color: colors.text }}>One surah</Text>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search a surah (name or number)"
            placeholderTextColor={colors.muted}
            style={{
              borderWidth: 1.5,
              borderColor: colors.border,
              borderRadius: 14,
              paddingHorizontal: 14,
              paddingVertical: 10,
              fontSize: 16,
              color: colors.text,
              backgroundColor: '#fff',
            }}
          />
          {matches.map((s) => {
            const saved = s.ayahs.filter((a) => cached.has(keyOf(s.id, a.n))).length;
            const full = saved === s.ayahs.length;
            return (
              <View key={s.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: colors.text, fontWeight: '700' }}>
                    {s.id}. {s.en}
                  </Text>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>
                    {saved}/{s.ayahs.length} ayahs saved
                  </Text>
                </View>
                <Button
                  label={full ? 'Saved' : 'Save'}
                  variant={full ? 'outline' : 'primary'}
                  disabled={job !== null || full}
                  onPress={() => run(s.en, s.ayahs.map((a) => ({ s: s.id, a: a.n })))}
                  style={{ minHeight: 40, paddingHorizontal: 18 }}
                />
              </View>
            );
          })}
        </Card>
      </ScrollView>
    </View>
  );
}
