import React, { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts } from '../theme';
import { MurajaahRow, addMurajaah, listMurajaah, removeMurajaah } from '../db/db';
import { QURAN, getSurah } from '../data/quranData';
import { describeDue, isDue } from '../lib/srs';
import { Button, Card, ScreenHeader } from '../components/ui';

export function MurajaahHomeScreen() {
  const nav = useNavigation<any>();
  const [rows, setRows] = useState<MurajaahRow[]>([]);

  const refresh = useCallback(() => {
    listMurajaah().then(setRows).catch(() => {});
  }, []);
  useFocusEffect(refresh);

  const [query, setQuery] = useState('');
  const memorized = new Set(rows.map((r) => r.surah));
  const q = query.trim().toLowerCase();
  // 114 surahs is too long to list: show matches only once the user searches (max 12).
  const matches = q
    ? QURAN.filter(
        (s) =>
          !memorized.has(s.id) &&
          (String(s.id) === q || s.en.toLowerCase().includes(q) || s.meaning.toLowerCase().includes(q) || s.ar.includes(q)),
      ).slice(0, 12)
    : [];

  const confirmRemove = (surah: number) =>
    Alert.alert('Remove from Murajaah?', `${getSurah(surah).en} will no longer be scheduled for review.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          await removeMurajaah(surah);
          refresh();
        },
      },
    ]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title="Murajaah Mode" subtitle="Spaced repetition for what you have memorized" />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
        {rows.length === 0 ? (
          <Card>
            <Text style={{ color: colors.text, textAlign: 'center' }}>
              Nothing to review yet. Finish a surah in Learn Mode, or add a surah you already know below.
            </Text>
          </Card>
        ) : null}

        {rows.map((r) => {
          const s = getSurah(r.surah);
          const due = isDue(r.due_at);
          return (
            <Pressable key={r.surah} onLongPress={() => confirmRemove(r.surah)}>
              <Card style={{ gap: 10 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 18, fontWeight: '800', color: colors.text }}>{s.en}</Text>
                    <Text style={{ color: due ? colors.wrong : colors.muted, fontWeight: due ? '700' : '400' }}>
                      {describeDue(r.due_at)}
                    </Text>
                  </View>
                  <Text style={{ fontFamily: fonts.arabicBold, fontSize: 26, color: colors.primary }}>{s.ar}</Text>
                </View>
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <Button
                    label="Review"
                    icon="sync"
                    variant={due ? 'primary' : 'outline'}
                    onPress={() => nav.navigate('MurajaahSession', { surah: r.surah })}
                    style={{ flex: 1, minHeight: 44 }}
                  />
                  <Button
                    label="Recite"
                    icon="mic"
                    variant="gold"
                    onPress={() => nav.navigate('ReciteSession', { surah: r.surah })}
                    style={{ flex: 1, minHeight: 44 }}
                  />
                </View>
              </Card>
            </Pressable>
          );
        })}

        {rows.length > 0 ? (
          <Text style={{ color: colors.muted, fontSize: 12, textAlign: 'center' }}>Long-press a surah to remove it.</Text>
        ) : null}

        <View style={{ gap: 8, marginTop: 8 }}>
          <Text style={{ fontWeight: '800', color: colors.text }}>I already know a surah</Text>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search a surah to add (name or number)"
            placeholderTextColor={colors.muted}
            style={{
              borderWidth: 1.5,
              borderColor: colors.border,
              borderRadius: 14,
              paddingHorizontal: 14,
              paddingVertical: 10,
              fontSize: 16,
              color: colors.text,
              backgroundColor: '#fff',
            }}
          />
          {q && matches.length === 0 ? (
            <Text style={{ color: colors.muted }}>No match (already added, or not found).</Text>
          ) : null}
          {matches.map((s) => (
              <Card key={s.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <Text style={{ flex: 1, fontSize: 16, color: colors.text, fontWeight: '600' }}>
                  {s.id}. {s.en} ({s.ayahs.length} ayahs)
                </Text>
                <Pressable
                  onPress={async () => {
                    await addMurajaah(s.id);
                    setQuery('');
                    refresh();
                  }}
                  hitSlop={8}
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
                >
                  <Ionicons name="add-circle" size={26} color={colors.primary} />
                  <Text style={{ color: colors.primary, fontWeight: '700' }}>Add</Text>
                </Pressable>
              </Card>
            ))}
        </View>
      </ScrollView>
    </View>
  );
}
