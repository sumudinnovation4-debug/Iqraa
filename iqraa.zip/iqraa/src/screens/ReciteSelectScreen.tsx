import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts } from '../theme';
import { QURAN } from '../data/quranData';
import { Card, ScreenHeader } from '../components/ui';

export function ReciteSelectScreen() {
  const nav = useNavigation<any>();
  const [query, setQuery] = useState('');

  const data = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return QURAN;
    return QURAN.filter(
      (s) =>
        String(s.id) === q ||
        s.en.toLowerCase().includes(q) ||
        s.meaning.toLowerCase().includes(q) ||
        s.ar.includes(q),
    );
  }, [query]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title="Recite Mode" subtitle="The Corrector: recite and get live feedback" />
      <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 8,
            borderWidth: 1.5,
            borderColor: colors.border,
            borderRadius: 14,
            paddingHorizontal: 12,
            backgroundColor: '#fff',
          }}
        >
          <Ionicons name="search" size={20} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search surah or number"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, paddingVertical: 10, fontSize: 16, color: colors.text }}
          />
        </View>
      </View>
      <FlatList
        data={data}
        keyExtractor={(s) => String(s.id)}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        initialNumToRender={12}
        ListHeaderComponent={
          <Text style={{ color: colors.muted, marginBottom: 6 }}>
            Pick a surah, then recite one ayah at a time. A wrong word turns red, the correct recitation plays, and you
            repeat it until it turns green. Long surah? Use "Go to ayah" inside to start anywhere.
          </Text>
        }
        ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: 'center' }}>No surah matches.</Text>}
        renderItem={({ item }) => (
          <Pressable onPress={() => nav.navigate('ReciteSession', { surah: item.id })}>
            <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View
                style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: colors.goldTint, alignItems: 'center', justifyContent: 'center' }}
              >
                <Ionicons name="mic" size={24} color={colors.goldDark} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 17, fontWeight: '800', color: colors.text }}>
                  {item.id}. {item.en}
                </Text>
                <Text style={{ color: colors.muted, fontSize: 13 }}>{item.ayahs.length} ayahs</Text>
              </View>
              <Text style={{ fontFamily: fonts.arabicBold, fontSize: 24, color: colors.primary }}>{item.ar}</Text>
            </Card>
          </Pressable>
        )}
      />
    </View>
  );
}
