import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts } from '../theme';
import { AyahRow, SurahRow, listBookmarks, listJuz, listSurahs, searchAyahs } from '../db/db';
import { Card, Chip, ScreenHeader } from '../components/ui';
import { Star8 } from '../components/Pattern';
import { useSessionTimer } from '../hooks';

export function ReadListScreen() {
  const nav = useNavigation<any>();
  useSessionTimer();
  const [query, setQuery] = useState('');
  const [juz, setJuz] = useState<number | null>(null);
  const [juzList, setJuzList] = useState<number[]>([]);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [surahs, setSurahs] = useState<SurahRow[]>([]);
  const [ayahHits, setAyahHits] = useState<AyahRow[]>([]);
  const [bookmarks, setBookmarks] = useState<AyahRow[]>([]);

  useEffect(() => {
    listJuz().then(setJuzList).catch(() => {});
  }, []);

  // Debounced so typing in a 6,236-ayah database stays smooth.
  useEffect(() => {
    const t = setTimeout(() => {
      listSurahs(query, juz).then(setSurahs).catch(() => {});
      searchAyahs(query).then(setAyahHits).catch(() => {});
    }, 200);
    return () => clearTimeout(t);
  }, [query, juz]);

  useFocusEffect(
    useCallback(() => {
      listBookmarks().then(setBookmarks).catch(() => {});
    }, []),
  );

  const openSurah = (surah: number, ayah?: number) => nav.navigate('Reader', { surah, ayah });

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScreenHeader title="Read Mode" subtitle="Quran with Hausa and English translation" />
      <View style={{ paddingHorizontal: 16, gap: 10, paddingBottom: 8 }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 8,
            borderWidth: 1.5,
            borderColor: colors.border,
            borderRadius: 14,
            paddingHorizontal: 12,
            backgroundColor: '#fff',
          }}
        >
          <Ionicons name="search" size={20} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search surah, number or text"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, paddingVertical: 10, fontSize: 16, color: colors.text }}
          />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingRight: 8 }}>
          <Chip label="All" active={juz === null && !showBookmarks} onPress={() => { setJuz(null); setShowBookmarks(false); }} />
          <Chip label={`Bookmarks (${bookmarks.length})`} active={showBookmarks} onPress={() => setShowBookmarks(true)} />
          {juzList.map((j) => (
            <Chip key={j} label={`Juz ${j}`} active={juz === j && !showBookmarks} onPress={() => { setJuz(j); setShowBookmarks(false); }} />
          ))}
        </ScrollView>
      </View>

      {showBookmarks ? (
        <FlatList
          data={bookmarks}
          keyExtractor={(a) => `${a.surah}:${a.n}`}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: 'center' }}>No bookmarks yet.</Text>}
          renderItem={({ item }) => <AyahHit item={item} onPress={() => openSurah(item.surah, item.n)} />}
        />
      ) : (
        <FlatList
          data={surahs}
          keyExtractor={(s) => String(s.id)}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: 'center' }}>No surah matches.</Text>}
          renderItem={({ item }) => (
            <Pressable onPress={() => openSurah(item.id)}>
              <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <View style={{ width: 46, height: 46, alignItems: 'center', justifyContent: 'center' }}>
                  <Star8 size={46} opacity={0.9} style={{ position: 'absolute' }} />
                  <Text style={{ fontWeight: '800', color: colors.primary }}>{item.id}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 17, fontWeight: '800', color: colors.text }}>{item.en}</Text>
                  <Text style={{ fontSize: 13, color: colors.muted }}>
                    {item.meaning} · {item.ayah_count} ayahs · Juz {item.juz}
                  </Text>
                </View>
                <Text style={{ fontFamily: fonts.arabicBold, fontSize: 24, color: colors.primary }}>{item.ar}</Text>
              </Card>
            </Pressable>
          )}
          ListFooterComponent={
            ayahHits.length > 0 ? (
              <View style={{ gap: 10, marginTop: 12 }}>
                <Text style={{ fontWeight: '800', color: colors.text }}>Matching ayahs</Text>
                {ayahHits.map((a) => (
                  <AyahHit key={`${a.surah}:${a.n}`} item={a} onPress={() => openSurah(a.surah, a.n)} />
                ))}
              </View>
            ) : null
          }
        />
      )}
    </View>
  );
}

function AyahHit({ item, onPress }: { item: AyahRow; onPress: () => void }) {
  return (
    <Pressable onPress={onPress}>
      <Card>
        <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 4 }}>
          {item.surah}:{item.n}
        </Text>
        <Text style={{ fontFamily: fonts.arabic, fontSize: 24, color: colors.text, textAlign: 'right', writingDirection: 'rtl' }}>
          {item.ar}
        </Text>
        <Text style={{ color: colors.text, marginTop: 6 }}>{item.en}</Text>
      </Card>
    </Pressable>
  );
}
