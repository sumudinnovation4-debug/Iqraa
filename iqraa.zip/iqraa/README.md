# Iqraa - Learn & Memorize Quran

React Native + Expo app with four modes: **Read**, **Learn**, **Recite (The Corrector)** and **Murajaah**.
Full Quran (114 surahs, 6,236 ayahs) in Uthmani Arabic with **Hausa** and English translations.
Free, no API keys, offline after first use.

## Fastest way to get the APK (no installs, no accounts)

1. New GitHub repo -> **Add file > Create new file**, name it `.github/workflows/upload.yml`, paste the
   contents of `upload.yml` (delivered next to this zip). Commit.
2. **Add file > Upload files**, drop `iqraa.zip` (do not unzip it), commit to `main`.
3. **Actions** tab -> open the run -> download the artifact `iqraa-apk-FULL-QURAN` -> unzip -> install `app-release.apk`.

If the artifact is named `iqraa-apk-MVP-ONLY`, the Quran download failed on the runner and the APK only has
Al-Fatiha and Al-Ikhlas. Open the step "Download and validate the full Quran" for the reason.

Other workflows in `.github/workflows/` (used if you push the *unzipped* project to `main`):
- `build.yml`: `expo export` + `eas build --platform android --local` -> `iqraa-apk`. Needs a free Expo token
  saved as repo secret `EXPO_TOKEN`.
- `build-no-account.yml`: manual run, Gradle only, no Expo account.

## Full Quran data

The repo ships Al-Fatiha and Al-Ikhlas in `src/data/quran.json` so it runs out of the box. `npm run build:data`
downloads the Uthmani text, Sahih International (English) and Abubakar Gumi (Hausa) from the free AlQuran Cloud
API, strips the Bismillah glued to ayah 1, and refuses to write the file unless it is exactly 114 surahs, the
known ayah count of every surah, 6,236 ayahs, no empty translations and sensible Juz numbers. All workflows
run it automatically. Existing installs re-seed their database when the data changes.

## Run locally

```bash
npm install
npx expo install --fix
npm run build:data            # full Quran (needs internet)
npx expo prebuild --platform android
npx expo run:android          # dev build; whisper.rn is native, Expo Go will not work
npm test
```

## Modes

| Mode | What it does |
| --- | --- |
| Read | Any surah, Hausa and/or English, EveryAyah audio (cached after first play, or "Save audio offline"), bookmarks, search by surah / Juz / number / text (Arabic ignores diacritics), curated tajweed notes for Al-Fatiha and Al-Ikhlas. |
| Learn | Noorani Qaida, Al-Fatiha, then all of Juz Amma (4 ayahs per lesson): listen, meaning quiz, missing word, word order. XP, levels, gems, streak, daily goal. Finishing a surah adds it to Murajaah. |
| Recite | Live on-device listening. Wrong word turns red, listening pauses, correct ayah audio plays, you repeat until green. "Go to ayah" for long surahs. Includes a no-microphone demo of the whole flow. |
| Murajaah | Spaced repetition for memorized surahs; add any of the 114 you already know. Recall ayah by ayah with hidden words, then rate Again / Hard / Good / Easy. |

Set **Profile > Translation** to Hausa, English or both; it applies across all four modes.

## Honest limits

- **Not run on a device by the author.** Pure logic is unit-tested (Arabic matching, spaced repetition,
  data building, lesson generation). The UI, SQLite, audio and speech recognition were written but could not
  be run in the environment where this was built. Install the APK and walk through every mode before relying on it.
- **Speech model.** `@xenova/transformers` does not run in React Native, so Recite uses `whisper.rn`
  (whisper.cpp, on-device). A multilingual Whisper model (Base 142 MB or Small 466 MB) downloads once from
  Hugging Face, then works offline. It is not Quran-specific: accuracy varies, and the opening letters of some
  surahs (e.g. Alif Lam Mim) are usually recognised as letter names, not as written.
- **What the checker can hear.** Words only. It cannot detect wrong harakat or tajweed errors. Keep a teacher.
- **Learn lessons** cover Noorani Qaida, Al-Fatiha and Juz Amma. Other surahs are available in Read, Recite and
  Murajaah.
- Surah search matches the English spellings in `src/data/surahNames.ts` (e.g. "Al-Fatiha", "Ya-Sin") or the number.
- Text attribution: Tanzil.net (Uthmani), Sahih International (English), Abubakar Mahmoud Gumi (Hausa),
  Mishary Alafasy via EveryAyah.com, data served by AlQuran Cloud.
